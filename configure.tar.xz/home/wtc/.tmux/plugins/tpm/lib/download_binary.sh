# Auto-download tpack binary from GitHub Releases.
# Usage: source this file, then call _download_tpack <tpm_root_dir>
# Returns 0 on success (binary installed at <tpm_root_dir>/tpack), non-zero on failure.

_TPACK_GITHUB_REPO="tmuxpack/tpack"

_download_tpack() {
	local root_dir="$1"

	# Opt-out via environment variable (current or legacy)
	if [ "${TPACK_AUTO_DOWNLOAD:-}" = "0" ] || [ "${TPM_AUTO_DOWNLOAD:-}" = "0" ]; then
		return 1
	fi

	# Detect OS
	local os
	case "$(uname -s)" in
		Linux)  os="linux" ;;
		Darwin) os="darwin" ;;
		FreeBSD) os="freebsd" ;;
		*) return 1 ;;
	esac

	# Detect architecture
	local arch
	case "$(uname -m)" in
		amd64|x86_64)  arch="amd64" ;;
		aarch64|arm64) arch="arm64" ;;
		*) return 1 ;;
	esac

	# Determine download tool
	local download_cmd=""
	if command -v curl >/dev/null 2>&1; then
		download_cmd="curl"
	elif command -v wget >/dev/null 2>&1; then
		download_cmd="wget"
	else
		return 1
	fi

	# Find latest release version via GitHub redirect
	local version=""
	if [ "$download_cmd" = "curl" ]; then
		version=$(curl -sI "https://github.com/${_TPACK_GITHUB_REPO}/releases/latest" 2>/dev/null \
			| grep -i '^location:' | sed 's|.*/tag/v\{0,1\}||' | tr -d '[:space:]')
	else
		version=$(wget --server-response --max-redirect=0 "https://github.com/${_TPACK_GITHUB_REPO}/releases/latest" 2>&1 \
			| grep -i 'location:' | sed 's|.*/tag/v\{0,1\}||' | tr -d '[:space:]')
	fi

	if [ -z "$version" ]; then
		return 1
	fi

	# Download archive to temp file
	local archive_name="tpack_${version}_${os}_${arch}.tar.gz"
	local url="https://github.com/${_TPACK_GITHUB_REPO}/releases/download/v${version}/${archive_name}"
	local tmp_dir
	tmp_dir=$(mktemp -d 2>/dev/null) || return 1
	local tmp_archive="${tmp_dir}/${archive_name}"

	if [ "$download_cmd" = "curl" ]; then
		curl -sL -o "$tmp_archive" "$url" 2>/dev/null || { rm -rf "$tmp_dir"; return 1; }
	else
		wget -q -O "$tmp_archive" "$url" 2>/dev/null || { rm -rf "$tmp_dir"; return 1; }
	fi

	# Verify we got a real file (not an HTML error page)
	if [ ! -s "$tmp_archive" ]; then
		rm -rf "$tmp_dir"
		return 1
	fi

	# Extract tpack binary
	tar -xzf "$tmp_archive" -C "$tmp_dir" tpack 2>/dev/null || { rm -rf "$tmp_dir"; return 1; }

	if [ ! -f "$tmp_dir/tpack" ]; then
		rm -rf "$tmp_dir"
		return 1
	fi

	# Move binary into place
	mv "$tmp_dir/tpack" "$root_dir/tpack" 2>/dev/null || { rm -rf "$tmp_dir"; return 1; }
	chmod +x "$root_dir/tpack" 2>/dev/null
	rm -rf "$tmp_dir"
	return 0
}
