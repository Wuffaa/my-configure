package integration_test

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/tmuxpack/tpack/internal/config"
	gitcli "github.com/tmuxpack/tpack/internal/git/cli"
	"github.com/tmuxpack/tpack/internal/manager"
	"github.com/tmuxpack/tpack/internal/plug"
	"github.com/tmuxpack/tpack/internal/tmux"
	"github.com/tmuxpack/tpack/internal/ui"
)

func TestInstallRealPlugin(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping Git integration test in -short mode")
	}
	skipIfNoGit(t)

	pluginDir, _ := setupIntegrationDir(t)

	cloner := gitcli.NewCloner()
	puller := gitcli.NewPuller()
	validator := gitcli.NewValidator()
	output := ui.NewMockOutput()

	mgr := manager.New(mustRoot(t, pluginDir), cloner, puller, validator, output)

	plugins := createLocalPlugins(t, tmuxExamplePlugin)
	p := plugins[0]

	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	mgr.Install(ctx, plugins)

	// Verify the plugin was cloned.
	dir := pluginPath(t, pluginDir, p)
	if _, err := os.Stat(dir); err != nil {
		t.Errorf("plugin directory not created: %v", err)
	}

	if output.Result() != nil {
		t.Errorf("install reported failure: %v", output.ErrMsgs)
	}

	// Install again should say "already installed".
	output2 := ui.NewMockOutput()
	mgr2 := manager.New(mustRoot(t, pluginDir), cloner, puller, validator, output2)
	mgr2.Install(ctx, plugins)

	found := false
	for _, msg := range output2.OkMsgs {
		if msg == "Already installed \"tmux-plugins/tmux-example-plugin\"" {
			found = true
		}
	}
	if !found {
		t.Errorf("expected 'Already installed' on second install, got: %v", output2.OkMsgs)
	}
}

func TestInstallMultiplePlugins(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping Git integration test in -short mode")
	}
	skipIfNoGit(t)

	pluginDir, _ := setupIntegrationDir(t)

	cloner := gitcli.NewCloner()
	puller := gitcli.NewPuller()
	validator := gitcli.NewValidator()
	output := ui.NewMockOutput()

	mgr := manager.New(mustRoot(t, pluginDir), cloner, puller, validator, output)

	plugins := createLocalPlugins(t, tmuxExamplePlugin, "tmux-plugins/tmux-sensible")

	ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
	defer cancel()
	mgr.Install(ctx, plugins)

	for _, p := range plugins {
		dir := pluginPath(t, pluginDir, p)
		if _, err := os.Stat(dir); err != nil {
			t.Errorf("plugin %s not installed: %v", p.Name, err)
		}
	}
}

func TestInstallNonexistentPlugin(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping Git integration test in -short mode")
	}
	skipIfNoGit(t)

	pluginDir, _ := setupIntegrationDir(t)

	cloner := gitcli.NewCloner()
	puller := gitcli.NewPuller()
	validator := gitcli.NewValidator()
	output := ui.NewMockOutput()

	mgr := manager.New(mustRoot(t, pluginDir), cloner, puller, validator, output)

	p := mustParsePlugin(t, "https://plugins.test/nonexistent/plugin.git")
	configureGitURLRewrites(t, map[string]string{p.Spec: filepath.Join(t.TempDir(), "missing.git")})
	plugins := []plug.Plugin{p}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	mgr.Install(ctx, plugins)

	if !errors.Is(output.Result(), ui.ErrReported) {
		t.Error("expected failure for nonexistent plugin")
	}
}

func TestConfigGatherPluginsFromFile(t *testing.T) {
	pluginDir, confFile := setupIntegrationDir(t)

	writeConf(t, confFile, `
set -g @plugin "tmux-plugins/tpm"
set -g @plugin "tmux-plugins/tmux-sensible"
set -g @plugin "user/repo#develop"
`)

	fs := config.RealFS{}
	plugins, err := config.GatherPlugins(
		&noopRunner{},
		fs,
		config.Paths{
			TmuxConf:   confFile,
			PluginPath: mustRoot(t, pluginDir),
			Home:       os.Getenv("HOME"),
		},
		nil,
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(plugins) != 3 {
		t.Fatalf("expected 3 plugins, got %d", len(plugins))
	}
	if plugins[2].Branch != "develop" {
		t.Errorf("expected branch 'develop', got %q", plugins[2].Branch)
	}
}

// noopRunner is a tmux.Runner that returns empty values.
type noopRunner struct{}

func (n *noopRunner) ShowOption(string) (string, bool, error) { return "", false, nil }
func (n *noopRunner) ShowEnvironment(string) (string, error)  { return "", tmux.ErrNotSet }
func (n *noopRunner) ExpandFormat(string) (string, error)     { return "", nil }
func (n *noopRunner) SetEnvironment(string, string) error     { return nil }
func (n *noopRunner) BindKey(string, string, string) error    { return nil }
func (n *noopRunner) SourceFile(string) error                 { return nil }
func (n *noopRunner) DisplayMessage(string) error             { return nil }
func (n *noopRunner) RunShell(string) error                   { return nil }
func (n *noopRunner) CommandPrompt(string, string) error      { return nil }
func (n *noopRunner) Version() (string, error)                { return "tmux 3.4", nil }
func (n *noopRunner) StartServer() error                      { return nil }
func (n *noopRunner) ShowWindowOption(string) (string, error) { return "", nil }
func (n *noopRunner) SetOption(string, string) error          { return nil }
