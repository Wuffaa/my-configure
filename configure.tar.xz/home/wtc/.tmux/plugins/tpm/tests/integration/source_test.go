package integration_test

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	gitcli "github.com/tmuxpack/tpack/internal/git/cli"
	"github.com/tmuxpack/tpack/internal/manager"
	"github.com/tmuxpack/tpack/internal/plug"
	"github.com/tmuxpack/tpack/internal/ui"
)

func TestSourceExecutesTmuxFiles(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping source execution test in -short mode")
	}

	pluginDir, _ := setupIntegrationDir(t)
	markerFile := filepath.Join(t.TempDir(), "source-marker")
	p := mustParsePlugin(t, "example/test-plugin")

	// Create plugin directory and an executable .tmux file inside it.
	pluginSubDir := pluginPath(t, pluginDir, p)
	if err := os.MkdirAll(pluginSubDir, 0o755); err != nil {
		t.Fatal(err)
	}

	tmuxFile := filepath.Join(pluginSubDir, "test-plugin.tmux")
	script := "#!/bin/sh\ntouch " + markerFile + "\n"
	if err := os.WriteFile(tmuxFile, []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}

	cloner := gitcli.NewCloner()
	puller := gitcli.NewPuller()
	validator := gitcli.NewValidator()
	output := ui.NewMockOutput()

	mgr := manager.New(mustRoot(t, pluginDir), cloner, puller, validator, output)

	plugins := []plug.Plugin{p}
	mgr.Source(context.Background(), plugins)

	if _, err := os.Stat(markerFile); err != nil {
		t.Errorf("expected marker file to exist after Source(), got: %v", err)
	}
}

func TestSourceSkipsNonExistentPluginDir(t *testing.T) {
	pluginDir, _ := setupIntegrationDir(t)

	cloner := gitcli.NewCloner()
	puller := gitcli.NewPuller()
	validator := gitcli.NewValidator()
	output := ui.NewMockOutput()

	mgr := manager.New(mustRoot(t, pluginDir), cloner, puller, validator, output)

	plugins := []plug.Plugin{mustParsePlugin(t, "example/nonexistent-plugin")}

	// Should not panic or error.
	mgr.Source(context.Background(), plugins)

	if output.Result() != nil {
		t.Errorf("expected no errors for non-existent plugin dir, got: %v", output.ErrMsgs)
	}
}
