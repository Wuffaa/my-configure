// Package ui provides output abstractions for tpack.
package ui

// Output abstracts message display for different output modes.
type Output interface {
	// Ok displays a success/informational message.
	Ok(msg string)

	// Warn displays a non-fatal warning. Unlike Err, it does not mark the
	// output as failed.
	Warn(msg string)

	// Err displays an error message and marks the output as failed.
	Err(msg string)

	// EndMessage displays the completion message with instructions.
	EndMessage()

	// Result returns semantic and output delivery failures recorded so far.
	Result() error
}
