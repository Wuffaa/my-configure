package tui

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	tea "charm.land/bubbletea/v2"
	"github.com/tmuxpack/tpack/internal/git"
	"github.com/tmuxpack/tpack/internal/plug"
	"github.com/tmuxpack/tpack/internal/registry"
)

func newBrowseModel(t *testing.T) Model {
	t.Helper()
	m := newTestModel(t, nil)
	m.screen = ScreenBrowse
	m.browseRegistry = &registry.Registry{
		Categories: []string{"theme", "session", "utility"},
		Plugins: []registry.RegistryItem{
			{Repo: "catppuccin/tmux", Description: "Pastel theme", Category: "theme", Stars: 1250},
			{Repo: "tmux-plugins/tmux-resurrect", Description: "Persist environment", Category: "session", Stars: 11400},
			{Repo: "tmux-plugins/tmux-sensible", Description: "Sensible defaults", Category: "utility", Stars: 5000},
		},
	}
	m.browseResults = m.browseRegistry.Plugins
	m.browseCategory = -2
	return m
}

func TestBrowseUpdate_TabCyclesCategory(t *testing.T) {
	m := newBrowseModel(t)
	m.browseCategory = -1 // start at "all" to test the original cycle behavior

	msg := tea.KeyPressMsg{Code: tea.KeyTab}
	result, _ := m.Update(msg)
	m = result.(Model)
	if m.browseCategory != 0 {
		t.Errorf("expected category 0, got %d", m.browseCategory)
	}

	result, _ = m.Update(msg)
	m = result.(Model)
	if m.browseCategory != 1 {
		t.Errorf("expected category 1, got %d", m.browseCategory)
	}

	// Cycle through remaining categories to wrap
	result, _ = m.Update(msg)
	m = result.(Model)
	result, _ = m.Update(msg)
	m = result.(Model)
	if m.browseCategory != -2 {
		t.Errorf("expected category -2 (new), got %d", m.browseCategory)
	}
}

func TestBrowseUpdate_ShiftTabCyclesBackward(t *testing.T) {
	m := newBrowseModel(t)
	m.browseCategory = -2 // start at "new"

	msg := tea.KeyPressMsg{Code: tea.KeyTab, Mod: tea.ModShift}

	// -2 (new) wraps to last category (2 = "utility")
	result, _ := m.Update(msg)
	m = result.(Model)
	if m.browseCategory != 2 {
		t.Errorf("expected category 2, got %d", m.browseCategory)
	}

	// 2 -> 1
	result, _ = m.Update(msg)
	m = result.(Model)
	if m.browseCategory != 1 {
		t.Errorf("expected category 1, got %d", m.browseCategory)
	}

	// 1 -> 0 -> -1 -> -2
	result, _ = m.Update(msg)
	m = result.(Model)
	result, _ = m.Update(msg)
	m = result.(Model)
	result, _ = m.Update(msg)
	m = result.(Model)
	if m.browseCategory != -2 {
		t.Errorf("expected category -2 (new), got %d", m.browseCategory)
	}
}

func TestBrowseUpdate_CursorNavigation(t *testing.T) {
	m := newBrowseModel(t)

	down := tea.KeyPressMsg{Code: tea.KeyDown}
	result, _ := m.Update(down)
	m = result.(Model)
	if m.browseScroll.cursor != 1 {
		t.Errorf("expected cursor 1, got %d", m.browseScroll.cursor)
	}

	up := tea.KeyPressMsg{Code: tea.KeyUp}
	result, _ = m.Update(up)
	m = result.(Model)
	if m.browseScroll.cursor != 0 {
		t.Errorf("expected cursor 0, got %d", m.browseScroll.cursor)
	}
}

func TestBrowseUpdate_EscReturnsToList(t *testing.T) {
	m := newBrowseModel(t)

	msg := tea.KeyPressMsg{Code: tea.KeyEscape}
	result, _ := m.Update(msg)
	m = result.(Model)
	if m.screen != ScreenList {
		t.Errorf("expected ScreenList, got %d", m.screen)
	}
}

func TestUpdate_BrowseKeyOpensBrowse(t *testing.T) {
	m := newTestModel(t, nil)
	msg := tea.KeyPressMsg{Code: 'b', Text: "b"}
	result, cmd := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenBrowse {
		t.Errorf("expected ScreenBrowse, got %d", m.screen)
	}
	if cmd == nil {
		t.Error("expected non-nil command (registry fetch)")
	}
}

func TestBrowseRoundTrip(t *testing.T) {
	m := newTestModel(t, nil)

	browse := tea.KeyPressMsg{Code: 'b', Text: "b"}
	result, _ := m.Update(browse)
	m = result.(Model)
	if m.screen != ScreenBrowse {
		t.Fatalf("expected ScreenBrowse, got %d", m.screen)
	}

	result, _ = m.Update(registryFetchResultMsg{
		Registry: &registry.Registry{
			Categories: []string{"theme"},
			Plugins: []registry.RegistryItem{
				{Repo: "catppuccin/tmux", Description: "Theme", Category: "theme", Stars: 100},
			},
		},
	})
	m = result.(Model)
	if m.browseLoading {
		t.Error("expected loading to be false after fetch")
	}
	if len(m.browseResults) != 1 {
		t.Errorf("expected 1 result, got %d", len(m.browseResults))
	}

	esc := tea.KeyPressMsg{Code: tea.KeyEscape}
	result, _ = m.Update(esc)
	m = result.(Model)
	if m.screen != ScreenList {
		t.Errorf("expected ScreenList, got %d", m.screen)
	}
}

func TestOpenFromBrowse_ReturnsCmd(t *testing.T) {
	m := newBrowseModel(t)
	m.browseScroll.cursor = 0

	_, cmd := m.openFromBrowse()
	if cmd == nil {
		t.Error("expected non-nil command for valid cursor")
	}
}

func TestOpenFromBrowse_InvalidCursor(t *testing.T) {
	m := newBrowseModel(t)
	m.browseScroll.cursor = 99

	_, cmd := m.openFromBrowse()
	if cmd != nil {
		t.Error("expected nil command for out-of-bounds cursor")
	}
}

func TestOpenFromBrowse_EnterKeyInNavMode(t *testing.T) {
	m := newBrowseModel(t)
	m.browseScroll.cursor = 0

	msg := tea.KeyPressMsg{Code: tea.KeyEnter}
	_, cmd := m.Update(msg)
	if cmd == nil {
		t.Error("expected non-nil command from Enter in navigation mode")
	}
}

func TestOpenFromBrowse_GitHubURL(t *testing.T) {
	m := newBrowseModel(t)
	m.browseScroll.cursor = 0

	result, _ := m.openFromBrowse()
	m = result.(Model)

	if !strings.Contains(m.browseStatus, "https://github.com/catppuccin/tmux") {
		t.Errorf("expected GitHub URL in status, got %q", m.browseStatus)
	}
}

func TestOpenFromBrowse_NonGitHubHost(t *testing.T) {
	m := newBrowseModel(t)
	m.browseRegistry.Plugins = append(m.browseRegistry.Plugins, registry.RegistryItem{
		Repo: "gitlab-user/tmux-theme", Description: "A theme", Category: "theme", Stars: 10, Host: "gitlab.com",
	})
	m.browseResults = m.browseRegistry.Plugins
	m.browseScroll.cursor = len(m.browseResults) - 1

	result, _ := m.openFromBrowse()
	m = result.(Model)

	if !strings.Contains(m.browseStatus, "https://gitlab.com/gitlab-user/tmux-theme") {
		t.Errorf("expected GitLab URL in status, got %q", m.browseStatus)
	}
}

func TestBrowseUpdate_DefaultCategoryIsNew(t *testing.T) {
	m := newTestModel(t, nil)
	msg := tea.KeyPressMsg{Code: 'b', Text: "b"}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.browseCategory != -2 {
		t.Errorf("expected default browseCategory -2 (new), got %d", m.browseCategory)
	}
}

func TestBrowseUpdate_TabCyclesFromNew(t *testing.T) {
	m := newBrowseModel(t)
	m.browseCategory = -2

	msg := tea.KeyPressMsg{Code: tea.KeyTab}

	// -2 (new) -> -1 (all)
	result, _ := m.Update(msg)
	m = result.(Model)
	if m.browseCategory != -1 {
		t.Errorf("expected category -1 (all), got %d", m.browseCategory)
	}

	// -1 (all) -> 0 (theme)
	result, _ = m.Update(msg)
	m = result.(Model)
	if m.browseCategory != 0 {
		t.Errorf("expected category 0, got %d", m.browseCategory)
	}

	// cycle through all categories back to -2
	result, _ = m.Update(msg) // 1
	m = result.(Model)
	result, _ = m.Update(msg) // 2
	m = result.(Model)
	result, _ = m.Update(msg) // wraps to -2
	m = result.(Model)
	if m.browseCategory != -2 {
		t.Errorf("expected category -2 (new), got %d", m.browseCategory)
	}
}

func TestBrowseUpdate_HiddenCategoriesFiltered(t *testing.T) {
	m := newTestModel(t, nil)
	m.cfg.HiddenCategories = []string{"ai"}

	msg := tea.KeyPressMsg{Code: 'b', Text: "b"}
	result, _ := m.Update(msg)
	m = result.(Model)

	result, _ = m.Update(registryFetchResultMsg{
		Registry: &registry.Registry{
			Categories: []string{"ai", "theme", "utility"},
			Plugins: []registry.RegistryItem{
				{Repo: "agent/indicator", Description: "AI agent", Category: "ai", Stars: 22},
				{Repo: "catppuccin/tmux", Description: "Theme", Category: "theme", Stars: 1250},
				{Repo: "sensible/tmux", Description: "Sensible", Category: "utility", Stars: 5000},
			},
		},
	})
	m = result.(Model)

	// ai category should be removed
	for _, c := range m.browseRegistry.Categories {
		if c == "ai" {
			t.Error("ai category should be hidden")
		}
	}
	// ai plugins should be removed
	for _, p := range m.browseRegistry.Plugins {
		if p.Category == "ai" {
			t.Errorf("ai plugin %s should be hidden", p.Repo)
		}
	}
	if len(m.browseRegistry.Categories) != 2 {
		t.Errorf("expected 2 categories, got %d", len(m.browseRegistry.Categories))
	}
	if len(m.browseRegistry.Plugins) != 2 {
		t.Errorf("expected 2 plugins, got %d", len(m.browseRegistry.Plugins))
	}
}

func TestInstallFromBrowse_NonGitHubHost_UsesFullURL(t *testing.T) {
	m := newBrowseModel(t)
	tmpDir := t.TempDir()
	confPath := filepath.Join(tmpDir, "tmux.conf")
	os.WriteFile(confPath, []byte("# tmux config\n"), 0o644)
	m.cfg.TmuxConf = confPath

	m.browseRegistry = &registry.Registry{
		Categories: []string{"theme"},
		Plugins: []registry.RegistryItem{
			{Repo: "gitlab-user/tmux-theme", Description: "A theme", Category: "theme", Stars: 10, Host: "gitlab.com"},
		},
	}
	m.browseResults = m.browseRegistry.Plugins
	m.browseScroll.cursor = 0

	result, cmd := m.installFromBrowse()
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Fatalf("expected ScreenProgress, got %d", m.screen)
	}
	if m.totalItems != 1 {
		t.Errorf("expected 1 total item, got %d", m.totalItems)
	}
	if cmd == nil {
		t.Error("expected non-nil install command")
	}

	wantSpec := "https://gitlab.com/gitlab-user/tmux-theme"

	// Check that the plugin was added with the full URL spec.
	found := false
	for _, p := range m.plugins {
		if p.Spec == wantSpec {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected plugin with spec %q in plugins list", wantSpec)
	}

	data, _ := os.ReadFile(confPath)
	if !strings.Contains(string(data), wantSpec) {
		t.Errorf("expected full GitLab URL in tmux.conf, got:\n%s", data)
	}
}

func TestInstallFromBrowse_GitHubHost_UsesShorthand(t *testing.T) {
	m := newBrowseModel(t)
	tmpDir := t.TempDir()
	confPath := filepath.Join(tmpDir, "tmux.conf")
	os.WriteFile(confPath, []byte("# tmux config\n"), 0o644)
	m.cfg.TmuxConf = confPath

	m.browseScroll.cursor = 0

	result, cmd := m.installFromBrowse()
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Fatalf("expected ScreenProgress, got %d", m.screen)
	}
	if cmd == nil {
		t.Error("expected non-nil install command")
	}

	// Check plugin was added with shorthand spec (no URL prefix).
	found := false
	for _, p := range m.plugins {
		if p.Spec == "catppuccin/tmux" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected plugin with spec catppuccin/tmux in plugins list")
	}

	data, _ := os.ReadFile(confPath)
	content := string(data)
	if !strings.Contains(content, "catppuccin/tmux") {
		t.Errorf("expected shorthand repo in tmux.conf, got:\n%s", content)
	}
	if strings.Contains(content, "https://") {
		t.Errorf("expected no URL prefix for GitHub repo, got:\n%s", content)
	}
}

func TestInstallFromBrowse_AddsToPluginsAndStartsInstall(t *testing.T) {
	m := newBrowseModel(t)
	m.cfg.TmuxConf = filepath.Join(t.TempDir(), "tmux.conf")
	os.WriteFile(m.cfg.TmuxConf, []byte("# tmux config\n"), 0o644)

	m.browseScroll.cursor = 0

	result, cmd := m.installFromBrowse()
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress, got %d", m.screen)
	}
	if m.totalItems != 1 {
		t.Errorf("expected 1 pending install, got %d", m.totalItems)
	}
	if cmd == nil {
		t.Error("expected non-nil install command")
	}

	data, _ := os.ReadFile(m.cfg.TmuxConf)
	if !strings.Contains(string(data), "catppuccin/tmux") {
		t.Error("expected plugin line in tmux.conf")
	}
}

func TestInstallFromBrowse_AllowsSameBasenameRepository(t *testing.T) {
	rootDir := t.TempDir()
	m := newTestModel(t, []plug.Plugin{mustParsePlugin(t, "catppuccin/tmux")})
	m.cfg.PluginPath = mustRoot(t, rootDir)
	m.cfg.TmuxConf = filepath.Join(t.TempDir(), "tmux.conf")
	if err := os.WriteFile(m.cfg.TmuxConf, []byte("set -g @plugin \"catppuccin/tmux\"\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	m.screen = ScreenBrowse
	m.browseResults = []registry.RegistryItem{{Repo: "dracula/tmux"}}

	updated, cmd := m.installFromBrowse()
	m = updated.(Model)
	if cmd == nil {
		t.Fatal("same-basename repository did not queue an install")
	}
	if len(m.plugins) != 2 {
		t.Fatalf("plugins = %+v, want two repositories", m.plugins)
	}
	added := m.plugins[1]
	if added.Raw != "dracula/tmux" || added.Name != "dracula/tmux" || added.Identity != "github.com/dracula/tmux" || added.DirName != "tmux-e74ab6318c07" {
		t.Fatalf("added plugin fields = %+v", added)
	}
	data, err := os.ReadFile(m.cfg.TmuxConf)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(data), `set -g @plugin "dracula/tmux"`) {
		t.Fatalf("tmux.conf did not gain dracula/tmux:\n%s", data)
	}

	result := runOperationCmd(t, cmd, OpInstall)
	if result.DirName != "tmux-e74ab6318c07" {
		t.Fatalf("install result correlation = %#v", result)
	}
	cloner, ok := m.deps.Cloner.(*git.MockCloner)
	if !ok || len(cloner.Calls) != 1 || cloner.Calls[0].Dir != filepath.Join(rootDir, "tmux-e74ab6318c07") {
		t.Fatalf("clone calls = %+v", cloner)
	}
}

func TestInstallFromBrowse_ParseFailureDoesNotChangeConfig(t *testing.T) {
	m := newBrowseModel(t)
	m.cfg.TmuxConf = filepath.Join(t.TempDir(), "tmux.conf")
	const original = "# tmux config\n"
	if err := os.WriteFile(m.cfg.TmuxConf, []byte(original), 0o644); err != nil {
		t.Fatal(err)
	}
	m.browseRegistry = &registry.Registry{Plugins: []registry.RegistryItem{{Repo: ""}}}
	m.browseResults = m.browseRegistry.Plugins

	result, cmd := m.installFromBrowse()
	m = result.(Model)

	if cmd != nil {
		t.Fatal("expected no install command")
	}
	data, err := os.ReadFile(m.cfg.TmuxConf)
	if err != nil {
		t.Fatal(err)
	}
	if string(data) != original {
		t.Fatalf("tmux.conf changed to %q", data)
	}
	if !strings.Contains(m.browseStatus, "Failed to install") {
		t.Fatalf("browseStatus = %q, want install failure", m.browseStatus)
	}
}

func TestInstallFromBrowse_HostileRegistryEntryDoesNotChangeConfigOrQueueClone(t *testing.T) {
	tests := []registry.RegistryItem{
		{Repo: `owner/repo"; run-shell "touch /tmp/tpack-injected"; #`},
		{Repo: `owner/repo#main"; run-shell "touch /tmp/tpack-injected"; #`},
		{Host: `github.com"; run-shell "touch /tmp/tpack-injected"; #`, Repo: "owner/repo"},
		{Host: `attacker";@github.com`, Repo: "owner/repo"},
		{Host: "github.com/../attacker.example", Repo: "owner/repo"},
		{Host: "github.com/attacker", Repo: "owner/repo"},
		{Host: "github.com", Repo: "owner/../repo"},
	}

	for _, item := range tests {
		t.Run(item.Host+item.Repo, func(t *testing.T) {
			m := newBrowseModel(t)
			m.cfg.TmuxConf = filepath.Join(t.TempDir(), "tmux.conf")
			const original = "# tmux config\n"
			if err := os.WriteFile(m.cfg.TmuxConf, []byte(original), 0o600); err != nil {
				t.Fatal(err)
			}
			m.browseResults = []registry.RegistryItem{item}
			before := len(m.plugins)

			updated, cmd := m.installFromBrowse()
			m = updated.(Model)
			if cmd != nil {
				t.Fatal("hostile entry queued an install")
			}
			if len(m.plugins) != before {
				t.Fatalf("plugins changed to %+v", m.plugins)
			}
			data, err := os.ReadFile(m.cfg.TmuxConf)
			if err != nil {
				t.Fatal(err)
			}
			if string(data) != original {
				t.Fatalf("tmux.conf changed to %q", data)
			}
			cloner := m.deps.Cloner.(*git.MockCloner)
			if len(cloner.Calls) != 0 {
				t.Fatalf("clone calls = %+v", cloner.Calls)
			}
			if !strings.Contains(m.browseStatus, "Failed to install") {
				t.Fatalf("browseStatus = %q", m.browseStatus)
			}
		})
	}
}

func TestInstallFromBrowse_PersistenceFailureDoesNotMutateOrQueue(t *testing.T) {
	tests := []string{"read tmux.conf", "open tmux.conf", "append tmux.conf"}
	for _, failure := range tests {
		t.Run(failure, func(t *testing.T) {
			m := newBrowseModel(t)
			m.cfg.TmuxConf = filepath.Join(t.TempDir(), "tmux.conf")
			m.deps.AppendPlugin = func(string, string) error { return errors.New(failure) }
			before := len(m.plugins)

			updated, cmd := m.installFromBrowse()
			m = updated.(Model)
			if cmd != nil {
				t.Fatal("persistence failure queued an install")
			}
			if len(m.plugins) != before {
				t.Fatalf("plugins changed to %+v", m.plugins)
			}
			if got := m.browseStatus; got != "Failed to install: "+failure {
				t.Fatalf("browseStatus = %q", got)
			}
			cloner := m.deps.Cloner.(*git.MockCloner)
			if len(cloner.Calls) != 0 {
				t.Fatalf("clone calls = %+v", cloner.Calls)
			}
		})
	}
}
