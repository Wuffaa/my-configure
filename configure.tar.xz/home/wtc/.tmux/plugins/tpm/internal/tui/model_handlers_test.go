package tui

import (
	"errors"
	"reflect"
	"strings"
	"testing"

	tea "charm.land/bubbletea/v2"
	"charm.land/lipgloss/v2"
	"github.com/tmuxpack/tpack/internal/git"
)

func TestHandleCheckResult_Outdated(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "alpha", DirName: "alpha", Status: StatusChecking},
	}

	msg := pluginCheckResultMsg{Name: "alpha", DirName: "alpha", Outdated: true}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.plugins[0].Status != StatusOutdated {
		t.Errorf("expected StatusOutdated, got %s", m.plugins[0].Status)
	}
}

func TestSameBasenameResultsUseDirectoryKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "tmux", DirName: "tmux-87a1216f1f68", Status: StatusNotInstalled},
		{Name: "tmux", DirName: "tmux-e74ab6318c07", Status: StatusNotInstalled},
	}
	m.screen = ScreenProgress
	m.operation = OpInstall
	m.processing = true
	m.inFlight = 1
	m.totalItems = 1
	m.inFlightNames = []string{"tmux"}

	updated, _ := m.Update(operationResultMsg{
		Operation:  OpInstall,
		ResultItem: ResultItem{Name: "tmux", DirName: "tmux-e74ab6318c07", Success: true, Message: "installed"},
	})
	m = updated.(Model)

	if m.plugins[0].Status != StatusNotInstalled {
		t.Fatalf("unrelated repository status = %s", m.plugins[0].Status)
	}
	if m.plugins[1].Status != StatusInstalled {
		t.Fatalf("completed repository status = %s", m.plugins[1].Status)
	}
	if len(m.results) != 1 || m.results[0].DirName != "tmux-e74ab6318c07" {
		t.Fatalf("result directory correlation = %+v", m.results)
	}
}

func TestSameBasenameCheckResultUsesDirectoryKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "tmux", DirName: "tmux-87a1216f1f68", Status: StatusChecking},
		{Name: "tmux", DirName: "tmux-e74ab6318c07", Status: StatusChecking},
	}

	updated, _ := m.Update(pluginCheckResultMsg{Name: "tmux", DirName: "tmux-e74ab6318c07", Outdated: true})
	m = updated.(Model)

	if m.plugins[0].Status != StatusChecking {
		t.Fatalf("unrelated repository status = %s", m.plugins[0].Status)
	}
	if m.plugins[1].Status != StatusOutdated {
		t.Fatalf("checked repository status = %s", m.plugins[1].Status)
	}
}

func TestHandleCheckResult_Error(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "alpha", DirName: "alpha", Status: StatusChecking},
	}

	msg := pluginCheckResultMsg{Name: "alpha", DirName: "alpha", Err: errors.New("fetch failed")}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.plugins[0].Status != StatusCheckFailed {
		t.Errorf("expected StatusCheckFailed, got %s", m.plugins[0].Status)
	}
}

func TestHandleCheckResult_UpToDate(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "alpha", DirName: "alpha", Status: StatusChecking},
	}

	msg := pluginCheckResultMsg{Name: "alpha", DirName: "alpha", Outdated: false, Err: nil}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.plugins[0].Status != StatusInstalled {
		t.Errorf("expected StatusInstalled, got %s", m.plugins[0].Status)
	}
}

func TestHandleCheckResult_UnknownPlugin(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "alpha", DirName: "alpha", Status: StatusChecking},
	}

	// Should not panic when the plugin name doesn't match any known plugin.
	msg := pluginCheckResultMsg{Name: "nonexistent", DirName: "nonexistent", Outdated: true}
	result, _ := m.Update(msg)
	_ = result.(Model) // should not panic
}

func TestOperationResultMessage(t *testing.T) {
	m := newProcessingTestModel(t, OpInstall, "alpha", []PluginItem{
		testPluginItem("alpha", "user/alpha", StatusNotInstalled),
	})
	result := ResultItem{Name: "alpha", DirName: "alpha", Success: true, Message: "installed"}

	m = updateTestModel(t, m, operationResultMsg{Operation: OpInstall, ResultItem: result})

	if m.plugins[0].Status != StatusInstalled {
		t.Errorf("plugin status = %s, want %s", m.plugins[0].Status, StatusInstalled)
	}
	if !reflect.DeepEqual(m.results, []ResultItem{result}) {
		t.Errorf("results = %+v, want %+v", m.results, []ResultItem{result})
	}
	if m.completedItems != 1 || m.inFlight != 0 || len(m.inFlightNames) != 0 || m.processing {
		t.Errorf("operation lifecycle = completed:%d in-flight:%d names:%v processing:%t",
			m.completedItems, m.inFlight, m.inFlightNames, m.processing)
	}
}

func TestOperationResults(t *testing.T) {
	tests := []struct {
		name         string
		operation    Operation
		inFlightName string
		plugins      []PluginItem
		msg          tea.Msg
		wantPlugins  []PluginItem
		wantResults  []ResultItem
	}{
		{
			name:         "install success",
			operation:    OpInstall,
			inFlightName: "alpha",
			plugins:      []PluginItem{testPluginItem("alpha", "user/alpha", StatusNotInstalled)},
			msg:          operationResultMsg{Operation: OpInstall, ResultItem: ResultItem{Name: "alpha", DirName: "alpha", Success: true, Message: "installed"}},
			wantPlugins:  []PluginItem{{Raw: "user/alpha", Name: "alpha", DirName: "alpha", Spec: "user/alpha", Status: StatusInstalled}},
			wantResults:  []ResultItem{{Name: "alpha", DirName: "alpha", Success: true, Message: "installed"}},
		},
		{
			name:         "install failure",
			operation:    OpInstall,
			inFlightName: "alpha",
			plugins:      []PluginItem{testPluginItem("alpha", "user/alpha", StatusNotInstalled)},
			msg:          operationResultMsg{Operation: OpInstall, ResultItem: ResultItem{Name: "alpha", DirName: "alpha", Success: false, Message: "clone failed"}},
			wantPlugins:  []PluginItem{{Raw: "user/alpha", Name: "alpha", DirName: "alpha", Spec: "user/alpha", Status: StatusNotInstalled}},
			wantResults:  []ResultItem{{Name: "alpha", DirName: "alpha", Success: false, Message: "clone failed"}},
		},
		{
			name:         "update success",
			operation:    OpUpdate,
			inFlightName: "alpha",
			plugins:      []PluginItem{testPluginItem("alpha", "user/alpha", StatusInstalled)},
			msg:          operationResultMsg{Operation: OpUpdate, ResultItem: ResultItem{Name: "alpha", DirName: "alpha", Success: true, Message: "updated"}},
			wantPlugins:  []PluginItem{{Raw: "user/alpha", Name: "alpha", DirName: "alpha", Spec: "user/alpha", Status: StatusInstalled}},
			wantResults:  []ResultItem{{Name: "alpha", DirName: "alpha", Success: true, Message: "updated"}},
		},
		{
			name:         "clean success",
			operation:    OpClean,
			inFlightName: "orphan-a",
			msg:          operationResultMsg{Operation: OpClean, ResultItem: ResultItem{Name: "orphan-a", Success: true, Message: "removed"}},
			wantResults:  []ResultItem{{Name: "orphan-a", Success: true, Message: "removed"}},
		},
		{
			name:         "uninstall success",
			operation:    OpUninstall,
			inFlightName: "alpha",
			plugins:      []PluginItem{testPluginItem("alpha", "user/alpha", StatusInstalled)},
			msg:          operationResultMsg{Operation: OpUninstall, ResultItem: ResultItem{Name: "alpha", DirName: "alpha", Success: true, Message: "removed"}},
			wantPlugins:  []PluginItem{{Raw: "user/alpha", Name: "alpha", DirName: "alpha", Spec: "user/alpha", Status: StatusNotInstalled}},
			wantResults:  []ResultItem{{Name: "alpha", DirName: "alpha", Success: true, Message: "removed"}},
		},
		{
			name:         "remove success",
			operation:    OpRemove,
			inFlightName: "alpha",
			plugins: []PluginItem{
				testPluginItem("alpha", "user/alpha", StatusInstalled),
				testPluginItem("beta", "user/beta", StatusInstalled),
			},
			msg:         operationResultMsg{Operation: OpRemove, ResultItem: ResultItem{Name: "alpha", DirName: "alpha", Success: true, Message: "removed successfully"}},
			wantPlugins: []PluginItem{{Raw: "user/beta", Name: "beta", DirName: "beta", Spec: "user/beta", Status: StatusInstalled}},
			wantResults: []ResultItem{{Name: "alpha", DirName: "alpha", Success: true, Message: "removed successfully"}},
		},
		{
			name:         "remove failure still removes plugin",
			operation:    OpRemove,
			inFlightName: "alpha",
			plugins:      []PluginItem{testPluginItem("alpha", "user/alpha", StatusInstalled)},
			msg:          operationResultMsg{Operation: OpRemove, ResultItem: ResultItem{Name: "alpha", DirName: "alpha", Success: false, Message: "permission denied"}},
			wantPlugins:  []PluginItem{},
			wantResults:  []ResultItem{{Name: "alpha", DirName: "alpha", Success: false, Message: "permission denied"}},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			m := newProcessingTestModel(t, tt.operation, tt.inFlightName, tt.plugins)
			m = updateTestModel(t, m, tt.msg)

			if !reflect.DeepEqual(m.plugins, tt.wantPlugins) {
				t.Errorf("plugins = %+v, want %+v", m.plugins, tt.wantPlugins)
			}
			if !reflect.DeepEqual(m.results, tt.wantResults) {
				t.Errorf("results = %+v, want %+v", m.results, tt.wantResults)
			}
			if m.completedItems != 1 {
				t.Errorf("completedItems = %d, want 1", m.completedItems)
			}
			if m.inFlight != 0 {
				t.Errorf("inFlight = %d, want 0", m.inFlight)
			}
			if len(m.inFlightNames) != 0 {
				t.Errorf("inFlightNames = %v, want empty", m.inFlightNames)
			}
			if m.processing {
				t.Error("processing = true, want false")
			}
		})
	}
}

func TestUpdateList_RemoveKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("alpha", "user/alpha", StatusInstalled),
	}
	m.viewHeight = 10

	msg := tea.KeyPressMsg{Code: 'r', Text: "r"}
	result, cmd := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress after 'r', got %d", m.screen)
	}
	if m.operation != OpRemove {
		t.Errorf("expected OpRemove, got %d", m.operation)
	}
	if cmd == nil {
		t.Error("expected non-nil command after remove")
	}
}

func TestReturnToList_RemovesCleanedOrphans(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.operation = OpClean
	m.processing = false
	m.orphans = []OrphanItem{
		{Name: "cleaned", DirName: "cleaned", Path: "/tmp/cleaned"},
		{Name: "remaining", DirName: "remaining", Path: "/tmp/remaining"},
	}
	m.results = []ResultItem{
		{Name: "cleaned", DirName: "cleaned", Success: true, Message: "removed"},
	}

	m = m.returnToList()

	if len(m.orphans) != 1 {
		t.Fatalf("expected 1 remaining orphan, got %d", len(m.orphans))
	}
	if m.orphans[0].Name != "remaining" {
		t.Errorf("expected remaining orphan 'remaining', got %q", m.orphans[0].Name)
	}
}

func TestReturnToListRemovesCleanedOrphanByDirectoryKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.operation = OpClean
	m.orphans = []OrphanItem{
		{Name: "shared label", DirName: "orphan-a", Path: "/plugins/orphan-a"},
		{Name: "shared label", DirName: "orphan-b", Path: "/plugins/orphan-b"},
	}
	m.results = []ResultItem{{
		Name: "shared label", DirName: "orphan-b", Success: true, Message: "removed",
	}}

	m = m.returnToList()

	if len(m.orphans) != 1 || m.orphans[0].DirName != "orphan-a" {
		t.Fatalf("remaining orphans = %+v", m.orphans)
	}
}

func TestReturnToList_ClampsNegativeCursor(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = nil
	m.listScroll.cursor = 5
	m.screen = ScreenProgress
	m.operation = OpClean
	m.processing = false

	m = m.returnToList()

	if m.listScroll.cursor != 0 {
		t.Errorf("expected cursor clamped to 0, got %d", m.listScroll.cursor)
	}
}

func TestMoveCursorDown_Scrolling(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = make([]PluginItem, 20)
	for i := range m.plugins {
		m.plugins[i] = PluginItem{Name: "plugin", Status: StatusInstalled}
	}
	m.viewHeight = 5
	m.listScroll.scrollOffset = 0
	m.listScroll.cursor = 0

	// Move cursor down past the scroll threshold (viewHeight - ScrollOffsetMargin = 5-3 = 2).
	for range 3 {
		m.listScroll.moveDown(len(m.plugins), m.viewHeight)
	}

	if m.listScroll.scrollOffset == 0 {
		t.Error("expected scrollOffset to increase when cursor moves past visible area")
	}
	if m.listScroll.cursor != 3 {
		t.Errorf("expected cursor at 3, got %d", m.listScroll.cursor)
	}
}

func TestMoveCursorUp_Scrolling(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = make([]PluginItem, 20)
	for i := range m.plugins {
		m.plugins[i] = PluginItem{Name: "plugin", Status: StatusInstalled}
	}
	m.listScroll.scrollOffset = 10
	m.listScroll.cursor = 12

	// Move cursor up into the scroll margin zone.
	m.listScroll.moveUp()
	m.listScroll.moveUp()

	if m.listScroll.scrollOffset >= 10 {
		t.Error("expected scrollOffset to decrease when cursor moves above visible area")
	}
}

func TestHasCheckingPlugins(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "a", Status: StatusInstalled},
		{Name: "b", Status: StatusChecking},
	}

	if !m.hasCheckingPlugins() {
		t.Error("expected hasCheckingPlugins() to return true when a plugin is checking")
	}

	m.plugins = []PluginItem{
		{Name: "a", Status: StatusInstalled},
		{Name: "b", Status: StatusOutdated},
	}

	if m.hasCheckingPlugins() {
		t.Error("expected hasCheckingPlugins() to return false when no plugin is checking")
	}
}

func TestUpdateProgress_IgnoresKeysWhileProcessing(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = true
	m.operation = OpInstall
	m.totalItems = 1
	m.completedItems = 0

	msg := tea.KeyPressMsg{Code: 'q', Text: "q"}
	result, cmd := m.Update(msg)
	updated := result.(Model)

	// While processing, key presses (except force quit) should be ignored.
	if cmd != nil {
		t.Error("expected nil command while processing, got non-nil")
	}
	if updated.screen != ScreenProgress {
		t.Errorf("expected to stay on ScreenProgress, got %d", updated.screen)
	}
}

func TestUpdateProgress_EscReturnsToList(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	m.operation = OpInstall

	msg := tea.KeyPressMsg{Code: tea.KeyEscape}
	result, _ := m.Update(msg)
	updated := result.(Model)

	if updated.screen != ScreenList {
		t.Errorf("expected ScreenList after esc, got %d", updated.screen)
	}
}

func TestUpdateProgress_QuitWhenNotProcessing(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	m.operation = OpInstall

	msg := tea.KeyPressMsg{Code: 'q', Text: "q"}
	_, cmd := m.Update(msg)

	if cmd == nil {
		t.Error("expected quit command when q pressed on progress screen while not processing")
	}
}

func TestUpdateList_ToggleSelection(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "alpha", Status: StatusInstalled},
		{Name: "beta", Status: StatusNotInstalled},
	}
	m.viewHeight = 10

	// Press tab to toggle selection.
	msg := tea.KeyPressMsg{Code: tea.KeyTab}
	result, _ := m.Update(msg)
	m = result.(Model)

	if !m.selected[0] {
		t.Error("expected plugin at cursor to be selected after tab")
	}
	if !m.multiSelectActive {
		t.Error("expected multiSelectActive to be true after tab")
	}
}

func TestUpdateList_InstallKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("alpha", "user/alpha", StatusNotInstalled),
	}
	m.viewHeight = 10

	msg := tea.KeyPressMsg{Code: 'i', Text: "i"}
	result, cmd := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress after 'i', got %d", m.screen)
	}
	if m.operation != OpInstall {
		t.Errorf("expected OpInstall, got %d", m.operation)
	}
	if cmd == nil {
		t.Error("expected non-nil command after install")
	}
}

func TestUpdateList_UpdateKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("alpha", "user/alpha", StatusInstalled),
	}
	m.viewHeight = 10

	msg := tea.KeyPressMsg{Code: 'u', Text: "u"}
	result, cmd := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress after 'u', got %d", m.screen)
	}
	if m.operation != OpUpdate {
		t.Errorf("expected OpUpdate, got %d", m.operation)
	}
	if cmd == nil {
		t.Error("expected non-nil command after update")
	}
}

func TestUpdateList_CleanKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.orphans = []OrphanItem{
		{Name: "orphan", Path: "/tmp/orphan"},
	}
	m.viewHeight = 10

	msg := tea.KeyPressMsg{Code: 'c', Text: "c"}
	result, cmd := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress after 'c', got %d", m.screen)
	}
	if m.operation != OpClean {
		t.Errorf("expected OpClean, got %d", m.operation)
	}
	if cmd == nil {
		t.Error("expected non-nil command after clean")
	}
}

func TestUpdateList_UninstallKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("alpha", "user/alpha", StatusInstalled),
	}
	m.viewHeight = 10

	msg := tea.KeyPressMsg{Code: 'x', Text: "x"}
	result, cmd := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress after 'x', got %d", m.screen)
	}
	if m.operation != OpUninstall {
		t.Errorf("expected OpUninstall, got %d", m.operation)
	}
	if cmd == nil {
		t.Error("expected non-nil command after uninstall")
	}
}

func TestBuildCleanOps(t *testing.T) {
	m := newTestModel(t, nil)
	m.orphans = []OrphanItem{
		{Name: "orphan-a", DirName: "orphan-a", Path: "/tmp/orphan-a"},
		{Name: "orphan-b", DirName: "orphan-b", Path: "/tmp/orphan-b"},
	}

	ops := m.buildCleanOps()
	if len(ops) != 2 {
		t.Errorf("expected 2 clean ops, got %d", len(ops))
	}
	if ops[0].Name != "orphan-a" {
		t.Errorf("expected first op name 'orphan-a', got %q", ops[0].Name)
	}
	if ops[1].Name != "orphan-b" {
		t.Errorf("expected second op name 'orphan-b', got %q", ops[1].Name)
	}
}

func TestStartOperation_OpNone(t *testing.T) {
	m := newTestModel(t, nil)
	result, cmd := m.startOperation(OpNone)
	updated := result.(Model)

	if updated.screen != ScreenList {
		t.Errorf("expected to stay on ScreenList for OpNone, got %d", updated.screen)
	}
	if cmd != nil {
		t.Error("expected nil command for OpNone")
	}
}

func TestForceQuit_FromList(t *testing.T) {
	m := newTestModel(t, nil)

	msg := tea.KeyPressMsg{Code: 'c', Mod: tea.ModCtrl}
	_, cmd := m.Update(msg)

	if cmd == nil {
		t.Error("expected quit command on ctrl+c")
	}
}

func TestForceQuit_FromProgress(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = true

	msg := tea.KeyPressMsg{Code: 'c', Mod: tea.ModCtrl}
	_, cmd := m.Update(msg)

	if cmd == nil {
		t.Error("expected quit command on ctrl+c even while processing")
	}
}

func TestWindowSizeMsg_MinViewHeight(t *testing.T) {
	m := newTestModel(t, nil)
	// Set height so small that viewHeight would be less than MinViewHeight.
	msg := tea.WindowSizeMsg{Width: 80, Height: 5}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.viewHeight < MinViewHeight {
		t.Errorf("expected viewHeight >= %d, got %d", MinViewHeight, m.viewHeight)
	}
}

func TestWindowSizeMsg_ProgressBarWidthCapped(t *testing.T) {
	m := newTestModel(t, nil)
	msg := tea.WindowSizeMsg{Width: 200, Height: 40}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.progressBar.Width() > ProgressBarMaxWidth {
		t.Errorf("expected progressBar.Width <= %d, got %d", ProgressBarMaxWidth, m.progressBar.Width())
	}
}

func TestDefaultDimensions(t *testing.T) {
	m := newTestModel(t, nil)

	if m.width != FixedWidth {
		t.Errorf("expected default width %d, got %d", FixedWidth, m.width)
	}
	if m.height != FixedHeight {
		t.Errorf("expected default height %d, got %d", FixedHeight, m.height)
	}
}

func TestMoveCursorDown_AtEnd(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "a", Status: StatusInstalled},
		{Name: "b", Status: StatusInstalled},
	}
	m.viewHeight = 10
	m.listScroll.cursor = 1 // already at last plugin

	m.listScroll.moveDown(len(m.plugins), m.viewHeight)
	if m.listScroll.cursor != 1 {
		t.Errorf("expected cursor to remain at 1 when at end, got %d", m.listScroll.cursor)
	}
}

func TestMoveCursorUp_AtBeginning(t *testing.T) {
	m := newTestModel(t, nil)
	m.listScroll.cursor = 0

	m.listScroll.moveUp()
	if m.listScroll.cursor != 0 {
		t.Errorf("expected cursor to remain at 0 when at beginning, got %d", m.listScroll.cursor)
	}
}

func TestResultCursorNavigation(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	m.results = []ResultItem{
		{Name: "a", Success: true},
		{Name: "b", Success: true},
		{Name: "c", Success: true},
	}
	m.resultScroll.cursor = 0

	// Move down.
	m.resultScroll.moveDown(len(m.results), m.resultMaxVisible())
	if m.resultScroll.cursor != 1 {
		t.Errorf("expected resultCursor=1, got %d", m.resultScroll.cursor)
	}
	m.resultScroll.moveDown(len(m.results), m.resultMaxVisible())
	if m.resultScroll.cursor != 2 {
		t.Errorf("expected resultCursor=2, got %d", m.resultScroll.cursor)
	}
	// Can't go past end.
	m.resultScroll.moveDown(len(m.results), m.resultMaxVisible())
	if m.resultScroll.cursor != 2 {
		t.Errorf("expected resultCursor to stay at 2, got %d", m.resultScroll.cursor)
	}
	// Move up.
	m.resultScroll.moveUp()
	if m.resultScroll.cursor != 1 {
		t.Errorf("expected resultCursor=1, got %d", m.resultScroll.cursor)
	}
	// Can't go past start.
	m.resultScroll.moveUp()
	m.resultScroll.moveUp()
	if m.resultScroll.cursor != 0 {
		t.Errorf("expected resultCursor to stay at 0, got %d", m.resultScroll.cursor)
	}
}

func TestResultCursorDown_Scrolling(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	maxVis := m.resultMaxVisible()
	count := maxVis + 10
	m.results = make([]ResultItem, count)
	for i := range m.results {
		m.results[i] = ResultItem{Name: "plugin", Success: true}
	}
	m.resultScroll.cursor = 0
	m.resultScroll.scrollOffset = 0

	// Move cursor past the scroll threshold.
	for range maxVis {
		m.resultScroll.moveDown(len(m.results), m.resultMaxVisible())
	}

	if m.resultScroll.scrollOffset == 0 {
		t.Error("expected resultScrollOffset to increase when cursor moves past visible area")
	}
}

func TestResultCursorUp_Scrolling(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	maxVis := m.resultMaxVisible()
	count := maxVis + 10
	m.results = make([]ResultItem, count)
	for i := range m.results {
		m.results[i] = ResultItem{Name: "plugin", Success: true}
	}
	m.resultScroll.scrollOffset = 10
	m.resultScroll.cursor = 12

	// Move cursor up into the scroll margin zone.
	m.resultScroll.moveUp()
	m.resultScroll.moveUp()

	if m.resultScroll.scrollOffset >= 10 {
		t.Error("expected resultScrollOffset to decrease when cursor moves above visible area")
	}
}

func TestShowCommits_NoCommits(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	m.results = []ResultItem{
		{Name: "a", Success: true}, // no commits
	}
	m.resultScroll.cursor = 0

	ok := m.showCommits()
	if ok {
		t.Error("expected showCommits to return false for result with no commits")
	}
	if m.screen != ScreenProgress {
		t.Errorf("expected to stay on ScreenProgress, got %d", m.screen)
	}
}

func TestShowCommits_OutOfBounds(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	m.results = []ResultItem{
		{Name: "a", Success: true},
	}
	m.resultScroll.cursor = 5

	ok := m.showCommits()
	if ok {
		t.Error("expected showCommits to return false for out-of-bounds cursor")
	}
}

func TestShowCommits_WithCommits(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	m.results = []ResultItem{
		{
			Name:    "a",
			Success: true,
			Commits: []git.Commit{{Hash: "abc", Message: "test"}},
		},
	}
	m.resultScroll.cursor = 0

	ok := m.showCommits()
	if !ok {
		t.Error("expected showCommits to return true for result with commits")
	}
	if m.screen != ScreenCommits {
		t.Errorf("expected ScreenCommits, got %d", m.screen)
	}
	if m.commitViewName != "a" {
		t.Errorf("expected commitViewName 'a', got %q", m.commitViewName)
	}
	if len(m.commitViewCommits) != 1 {
		t.Errorf("expected 1 commit, got %d", len(m.commitViewCommits))
	}
}

func TestUpdateProgress_NavigationKeys(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.processing = false
	m.results = []ResultItem{
		{Name: "a", Success: true, Commits: []git.Commit{{Hash: "x", Message: "y"}}, Dir: "/tmp/p", BeforeRef: "aaa", AfterRef: "bbb"},
		{Name: "b", Success: true},
	}
	m.resultScroll.cursor = 0

	// Press j to move down.
	down := tea.KeyPressMsg{Code: 'j', Text: "j"}
	result, _ := m.Update(down)
	m = result.(Model)
	if m.resultScroll.cursor != 1 {
		t.Errorf("expected resultCursor=1 after j, got %d", m.resultScroll.cursor)
	}

	// Press k to move up.
	up := tea.KeyPressMsg{Code: 'k', Text: "k"}
	result, _ = m.Update(up)
	m = result.(Model)
	if m.resultScroll.cursor != 0 {
		t.Errorf("expected resultCursor=0 after k, got %d", m.resultScroll.cursor)
	}

	// Press enter - should navigate to commits screen for result with commits.
	enter := tea.KeyPressMsg{Code: tea.KeyEnter}
	result, _ = m.Update(enter)
	m = result.(Model)
	if m.screen != ScreenCommits {
		t.Errorf("expected ScreenCommits after enter on result with commits, got %d", m.screen)
	}
}

func TestHandleUpdateResult_WithCommits(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("alpha", "user/alpha", StatusInstalled),
	}
	m.screen = ScreenProgress
	m.operation = OpUpdate
	m.processing = true
	m.totalItems = 1
	m.completedItems = 0

	commits := []git.Commit{
		{Hash: "abc", Message: "add feature"},
		{Hash: "def", Message: "fix bug"},
	}
	msg := operationResultMsg{Operation: OpUpdate, ResultItem: ResultItem{
		Name: "alpha", DirName: "alpha", Success: true, Message: "updated", Commits: commits,
	}}
	result, _ := m.Update(msg)
	m = result.(Model)

	if len(m.results) != 1 {
		t.Fatalf("expected 1 result, got %d", len(m.results))
	}
	if len(m.results[0].Commits) != 2 {
		t.Errorf("expected 2 commits in result, got %d", len(m.results[0].Commits))
	}
}

func TestUpdateCommitView_EscReturnsToProgress(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenCommits
	m.commitViewName = "test"
	m.commitViewCommits = []git.Commit{{Hash: "abc", Message: "test"}}

	msg := tea.KeyPressMsg{Code: tea.KeyEscape}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress after esc, got %d", m.screen)
	}
	if m.commitViewName != "" {
		t.Errorf("expected commitViewName cleared, got %q", m.commitViewName)
	}
}

func TestUpdateCommitView_QReturnsToProgress(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenCommits
	m.commitViewName = "test"
	m.commitViewCommits = []git.Commit{{Hash: "abc", Message: "test"}}

	msg := tea.KeyPressMsg{Code: 'q', Text: "q"}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress after q, got %d", m.screen)
	}
}

func TestUpdateCommitView_Navigation(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenCommits
	m.commitViewName = "test"
	m.commitViewCommits = []git.Commit{
		{Hash: "aaa", Message: "first"},
		{Hash: "bbb", Message: "second"},
		{Hash: "ccc", Message: "third"},
	}
	m.commitScroll.cursor = 0

	// Move down.
	down := tea.KeyPressMsg{Code: 'j', Text: "j"}
	result, _ := m.Update(down)
	m = result.(Model)
	if m.commitScroll.cursor != 1 {
		t.Errorf("expected commitViewCursor=1 after j, got %d", m.commitScroll.cursor)
	}

	// Move up.
	up := tea.KeyPressMsg{Code: 'k', Text: "k"}
	result, _ = m.Update(up)
	m = result.(Model)
	if m.commitScroll.cursor != 0 {
		t.Errorf("expected commitViewCursor=0 after k, got %d", m.commitScroll.cursor)
	}
}

func TestViewCommits_Rendering(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenCommits
	m.commitViewName = "tmux-sensible"
	m.commitViewCommits = []git.Commit{
		{Hash: "abc1234", Message: "add feature X"},
		{Hash: "def5678", Message: "fix bug Y"},
	}

	view := m.View().Content
	if view == "" {
		t.Fatal("expected non-empty view")
	}
	if !strings.Contains(view, "tmux-sensible") {
		t.Error("expected view to contain plugin name")
	}
	if !strings.Contains(view, "2 new commits") {
		t.Error("expected view to show '2 new commits'")
	}
	if !strings.Contains(view, "abc1234") {
		t.Error("expected view to contain commit hash")
	}
	if !strings.Contains(view, "back") {
		t.Error("expected view to contain 'back' in help")
	}
}

func TestUpdateList_EnterOpensLoadError(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "tmux-statusline", Status: StatusLoadFailed, LoadErr: "line one\nline two"},
	}
	m.viewHeight = 10

	msg := tea.KeyPressMsg{Code: tea.KeyEnter}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenLoadError {
		t.Fatalf("expected ScreenLoadError, got %d", m.screen)
	}
	if m.loadErrName != "tmux-statusline" {
		t.Errorf("expected loadErrName set, got %q", m.loadErrName)
	}
	if len(m.loadErrLines) != 2 {
		t.Errorf("expected 2 message lines, got %d", len(m.loadErrLines))
	}
}

func TestUpdateList_EnterNoopOnHealthyPlugin(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{{Name: "ok", Status: StatusInstalled}}
	m.viewHeight = 10

	msg := tea.KeyPressMsg{Code: tea.KeyEnter}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenList {
		t.Errorf("expected to stay on ScreenList, got %d", m.screen)
	}
}

func TestLoadErrorWrappedLines_WrapsLongPath(t *testing.T) {
	m := newTestModel(t, nil)
	m.width = 40
	m.loadErrLines = []string{
		"error sourcing tmux-statusline.tmux: fork/exec /home/antoinegs/.tmux/plugins/tmux-statusline/tmux-statusline.tmux: exec format error",
	}

	lines := m.loadErrorWrappedLines()

	if len(lines) < 2 {
		t.Fatalf("expected long message to wrap into multiple lines, got %d", len(lines))
	}
	contentWidth := m.width - BaseStylePadding
	for i, l := range lines {
		if w := lipgloss.Width(l); w > contentWidth {
			t.Errorf("line %d width %d exceeds content width %d: %q", i, w, contentWidth, l)
		}
	}
}

func TestUpdateLoadError_EscReturnsToList(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenLoadError
	m.loadErrName = "x"
	m.loadErrLines = []string{"boom"}

	msg := tea.KeyPressMsg{Code: tea.KeyEscape}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.screen != ScreenList {
		t.Errorf("expected ScreenList after esc, got %d", m.screen)
	}
	if m.loadErrName != "" {
		t.Errorf("expected loadErrName cleared, got %q", m.loadErrName)
	}
	if len(m.loadErrLines) != 0 {
		t.Errorf("expected loadErrLines cleared, got %v", m.loadErrLines)
	}
}

func TestReturnToProgress_ClearsState(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenCommits
	m.commitViewName = "test"
	m.commitViewCommits = []git.Commit{{Hash: "abc", Message: "test"}}
	m.commitScroll.cursor = 2
	m.commitScroll.scrollOffset = 1

	m.returnToProgress()

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress, got %d", m.screen)
	}
	if m.commitViewName != "" {
		t.Errorf("expected commitViewName cleared, got %q", m.commitViewName)
	}
	if m.commitViewCommits != nil {
		t.Error("expected commitViewCommits cleared")
	}
	if m.commitScroll.cursor != 0 {
		t.Errorf("expected commitViewCursor reset to 0, got %d", m.commitScroll.cursor)
	}
	if m.commitScroll.scrollOffset != 0 {
		t.Errorf("expected commitViewScrollOffset reset to 0, got %d", m.commitScroll.scrollOffset)
	}
}
