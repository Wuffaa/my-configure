package tui

import (
	"strings"
	"testing"

	tea "charm.land/bubbletea/v2"
	"github.com/tmuxpack/tpack/internal/config"
	"github.com/tmuxpack/tpack/internal/git"
	"github.com/tmuxpack/tpack/internal/plug"
)

func TestStartCleanReportsOrphanDiscoveryFailureWithoutScheduling(t *testing.T) {
	m := NewModel(&config.Config{}, nil, Deps{})
	if m.orphanErr == nil {
		t.Fatal("NewModel did not retain orphan discovery failure")
	}

	result, cmd := m.startOperation(OpClean)
	m = result.(Model)

	if cmd != nil {
		t.Fatal("clean returned a command for an invalid root")
	}
	if m.screen != ScreenProgress {
		t.Fatalf("screen = %v, want ScreenProgress", m.screen)
	}
	if m.processing || m.inFlight != 0 || len(m.pendingItems) != 0 {
		t.Fatalf("cleanup was scheduled: processing=%v inFlight=%d pending=%d", m.processing, m.inFlight, len(m.pendingItems))
	}
	if len(m.results) != 1 || m.results[0].Success {
		t.Fatalf("results = %+v, want one failure", m.results)
	}
	if !strings.Contains(m.results[0].Message, "unsafe plugin directory") {
		t.Fatalf("failure message = %q", m.results[0].Message)
	}
}

func TestStartAutoCleanReportsOrphanDiscoveryFailureWithoutScheduling(t *testing.T) {
	m := NewModel(&config.Config{}, nil, Deps{}, WithAutoOp(OpClean))

	result, cmd := m.startAutoOperation()
	m = result.(Model)

	if cmd != nil {
		t.Fatal("automatic clean returned a command for an invalid root")
	}
	if m.screen != ScreenProgress {
		t.Fatalf("screen = %v, want ScreenProgress", m.screen)
	}
	if m.processing || m.inFlight != 0 || len(m.pendingItems) != 0 {
		t.Fatalf("cleanup was scheduled: processing=%v inFlight=%d pending=%d", m.processing, m.inFlight, len(m.pendingItems))
	}
	if len(m.results) != 1 || m.results[0].Success {
		t.Fatalf("results = %+v, want one failure", m.results)
	}
}

func testDeps() Deps {
	return Deps{
		Cloner:    git.NewMockCloner(),
		Puller:    git.NewMockPuller(),
		Validator: git.NewMockValidator(),
		Fetcher:   git.NewMockFetcher(),
		RevParser: git.NewMockRevParser(),
		Logger:    git.NewMockLogger(),
	}
}

func newTestModel(t *testing.T, plugins []plug.Plugin, opts ...ModelOption) Model {
	t.Helper()
	cfg := &config.Config{PluginPath: mustRoot(t, t.TempDir())}
	return NewModel(cfg, plugins, testDeps(), opts...)
}

func updateTestModel(t *testing.T, m Model, msg tea.Msg) Model {
	t.Helper()
	updated, _ := m.Update(msg)
	result, ok := updated.(Model)
	if !ok {
		t.Fatalf("Update returned %T, want Model", updated)
	}
	return result
}

func newProcessingTestModel(t *testing.T, operation Operation, name string, plugins []PluginItem) Model {
	t.Helper()
	m := newTestModel(t, nil)
	m.plugins = plugins
	m.screen = ScreenProgress
	m.operation = operation
	m.processing = true
	m.totalItems = 1
	m.inFlight = 1
	m.inFlightNames = []string{name}
	return m
}

func mustParsePlugin(t *testing.T, raw string) plug.Plugin {
	t.Helper()
	p, err := plug.ParseSpec(raw, nil)
	if err != nil {
		t.Fatalf("ParseSpec(%q): %v", raw, err)
	}
	return p
}

func testPlugin(name, spec string) plug.Plugin {
	return plug.Plugin{Raw: spec, Name: name, DirName: name, Spec: spec}
}

func testPluginItem(name, spec string, status PluginStatus) PluginItem {
	return PluginItem{Raw: spec, Name: name, DirName: name, Spec: spec, Status: status}
}

func TestNewModel_InitialState(t *testing.T) {
	plugins := []plug.Plugin{
		testPlugin("tmux-sensible", "tmux-plugins/tmux-sensible"),
		testPlugin("tmux-yank", "tmux-plugins/tmux-yank"),
	}
	m := newTestModel(t, plugins)

	if m.screen != ScreenList {
		t.Errorf("expected ScreenList, got %d", m.screen)
	}
	if m.operation != OpNone {
		t.Errorf("expected OpNone, got %d", m.operation)
	}
	if len(m.plugins) != 2 {
		t.Errorf("expected 2 plugins, got %d", len(m.plugins))
	}
	if m.listScroll.cursor != 0 {
		t.Errorf("expected cursor at 0, got %d", m.listScroll.cursor)
	}
	if len(m.selected) != 0 {
		t.Errorf("expected empty selection, got %d", len(m.selected))
	}
}

func TestNewModel_PluginStatus(t *testing.T) {
	plugins := []plug.Plugin{
		testPlugin("tmux-sensible", "tmux-plugins/tmux-sensible"),
	}
	m := newTestModel(t, plugins)

	// No plugin dirs exist in temp dir, so all should be NotInstalled.
	for _, p := range m.plugins {
		if p.Status != StatusNotInstalled {
			t.Errorf("expected StatusNotInstalled for %s, got %s", p.Name, p.Status)
		}
	}
}

func TestUpdate_QuitKey(t *testing.T) {
	m := newTestModel(t, nil)
	msg := tea.KeyPressMsg{Code: 'q', Text: "q"}
	_, cmd := m.Update(msg)
	if cmd == nil {
		t.Fatal("expected quit command, got nil")
	}
}

func TestUpdate_CursorNavigation(t *testing.T) {
	plugins := []plug.Plugin{
		testPlugin("a", "user/a"),
		testPlugin("b", "user/b"),
		testPlugin("c", "user/c"),
	}
	m := newTestModel(t, plugins)
	m.viewHeight = 10

	// Move down.
	down := tea.KeyPressMsg{Code: 'j', Text: "j"}
	result, _ := m.Update(down)
	m = result.(Model)
	if m.listScroll.cursor != 1 {
		t.Errorf("expected cursor at 1 after j, got %d", m.listScroll.cursor)
	}

	// Move down again.
	result, _ = m.Update(down)
	m = result.(Model)
	if m.listScroll.cursor != 2 {
		t.Errorf("expected cursor at 2 after j, got %d", m.listScroll.cursor)
	}

	// Move up.
	up := tea.KeyPressMsg{Code: 'k', Text: "k"}
	result, _ = m.Update(up)
	m = result.(Model)
	if m.listScroll.cursor != 1 {
		t.Errorf("expected cursor at 1 after k, got %d", m.listScroll.cursor)
	}

	// Can't go above 0.
	result, _ = m.Update(up)
	m = result.(Model)
	result, _ = m.Update(up)
	m = result.(Model)
	if m.listScroll.cursor != 0 {
		t.Errorf("expected cursor at 0, got %d", m.listScroll.cursor)
	}
}

func TestUpdate_WindowSize(t *testing.T) {
	m := newTestModel(t, nil)
	msg := tea.WindowSizeMsg{Width: 120, Height: 40}
	result, _ := m.Update(msg)
	m = result.(Model)

	if m.width != 120 {
		t.Errorf("expected width 120, got %d", m.width)
	}
	if m.height != 40 {
		t.Errorf("expected height 40, got %d", m.height)
	}
}

func TestView_NonEmpty(t *testing.T) {
	plugins := []plug.Plugin{
		testPlugin("tmux-sensible", "tmux-plugins/tmux-sensible"),
	}
	m := newTestModel(t, plugins)
	m.width = 80
	m.viewHeight = 20

	view := m.View().Content
	if view == "" {
		t.Error("expected non-empty view")
	}
}

func TestView_ProgressScreen(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.operation = OpInstall
	m.totalItems = 3
	m.completedItems = 1
	m.width = 80

	view := m.View().Content
	if view == "" {
		t.Error("expected non-empty progress view")
	}
}

func TestStartOperation_Install(t *testing.T) {
	plugins := []plug.Plugin{
		testPlugin("test-plugin", "user/test-plugin"),
	}
	m := newTestModel(t, plugins)
	// Plugin is not installed, so install should work.
	result, cmd := m.startOperation(OpInstall)
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress, got %d", m.screen)
	}
	if m.operation != OpInstall {
		t.Errorf("expected OpInstall, got %d", m.operation)
	}
	if m.totalItems != 1 {
		t.Errorf("expected 1 total item, got %d", m.totalItems)
	}
	if cmd == nil {
		t.Error("expected non-nil command")
	}
}

func TestStartOperation_NoOps(t *testing.T) {
	// All plugins installed → install has nothing to do.
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		{Name: "test", Status: StatusInstalled},
	}
	result, cmd := m.startOperation(OpInstall)
	m = result.(Model)

	if m.screen != ScreenList {
		t.Errorf("expected to stay on ScreenList, got %d", m.screen)
	}
	if cmd != nil {
		t.Error("expected nil command when no ops available")
	}
}

func TestReturnToList(t *testing.T) {
	m := newTestModel(t, nil)
	m.screen = ScreenProgress
	m.operation = OpClean
	m.processing = false

	m = m.returnToList()

	if m.screen != ScreenList {
		t.Errorf("expected ScreenList, got %d", m.screen)
	}
	if m.operation != OpNone {
		t.Errorf("expected OpNone, got %d", m.operation)
	}
}

func TestNewModel_WithAutoOp(t *testing.T) {
	plugins := []plug.Plugin{
		testPlugin("tmux-sensible", "tmux-plugins/tmux-sensible"),
	}
	m := newTestModel(t, plugins, WithAutoOp(OpInstall))

	if m.autoOp != OpInstall {
		t.Errorf("expected autoOp OpInstall, got %d", m.autoOp)
	}
	// Screen should still start at ScreenList (autoStart happens in Init).
	if m.screen != ScreenList {
		t.Errorf("expected ScreenList initially, got %d", m.screen)
	}
}

func TestInit_WithAutoOp_SendsAutoStartMsg(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpInstall))

	cmd := m.Init()
	if cmd == nil {
		t.Fatal("expected non-nil command from Init with autoOp")
	}
}

func TestInit_WithoutAutoOp_NoAutoStartMsg(t *testing.T) {
	// With no plugins (nothing to check), Init should still return a command
	// (for background color detection) but no autoStartMsg.
	m := newTestModel(t, nil)
	cmd := m.Init()
	if cmd == nil {
		t.Error("expected non-nil command from Init (background color request)")
	}
}

func TestStartAutoOperation_Install(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpInstall))
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusNotInstalled),
		testPluginItem("b", "user/b", StatusInstalled),
		testPluginItem("c", "user/c", StatusNotInstalled),
	}

	result, cmd := m.startAutoOperation()
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress, got %d", m.screen)
	}
	if m.operation != OpInstall {
		t.Errorf("expected OpInstall, got %d", m.operation)
	}
	if m.totalItems != 2 {
		t.Errorf("expected 2 total items (non-installed), got %d", m.totalItems)
	}
	if cmd == nil {
		t.Error("expected non-nil command")
	}
}

func TestStartAutoOperation_Update(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpUpdate))
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusInstalled),
		testPluginItem("b", "user/b", StatusNotInstalled),
		testPluginItem("c", "user/c", StatusOutdated),
	}

	result, cmd := m.startAutoOperation()
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress, got %d", m.screen)
	}
	if m.totalItems != 2 {
		t.Errorf("expected 2 total items (installed+outdated), got %d", m.totalItems)
	}
	if cmd == nil {
		t.Error("expected non-nil command")
	}
}

func TestStartAutoOperation_Clean(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpClean))
	m.orphans = []OrphanItem{
		{Name: "orphan1", Path: "/tmp/orphan1"},
		{Name: "orphan2", Path: "/tmp/orphan2"},
	}

	result, cmd := m.startAutoOperation()
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress, got %d", m.screen)
	}
	if m.totalItems != 2 {
		t.Errorf("expected 2 total items (orphans), got %d", m.totalItems)
	}
	if cmd == nil {
		t.Error("expected non-nil command")
	}
}

func TestStartAutoOperation_NoOps_Quits(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpInstall))
	m.plugins = []PluginItem{
		{Name: "a", Spec: "user/a", Status: StatusInstalled},
	}

	_, cmd := m.startAutoOperation()
	if cmd == nil {
		t.Fatal("expected non-nil quit command when no ops available")
	}
}

func TestUpdateProgress_AutoOp_QuitOnQ(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpInstall))
	m.screen = ScreenProgress
	m.processing = false

	msg := tea.KeyPressMsg{Code: 'q', Text: "q"}
	_, cmd := m.handleKeyMsgProgress(msg)
	if cmd == nil {
		t.Fatal("expected quit command on q in auto-op mode")
	}
}

func TestUpdateProgress_AutoOp_QuitOnEsc(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpInstall))
	m.screen = ScreenProgress
	m.processing = false

	msg := tea.KeyPressMsg{Code: tea.KeyEscape}
	_, cmd := m.handleKeyMsgProgress(msg)
	if cmd == nil {
		t.Fatal("expected quit command on Esc in auto-op mode")
	}
}

func TestUpdateProgress_AutoOp_IgnoresKeysWhileProcessing(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpInstall))
	m.screen = ScreenProgress
	m.processing = true

	msg := tea.KeyPressMsg{Code: 'q', Text: "q"}
	_, cmd := m.handleKeyMsgProgress(msg)
	if cmd != nil {
		t.Error("expected nil command when still processing")
	}
}

func TestUpdate_AutoStartMsg(t *testing.T) {
	m := newTestModel(t, nil, WithAutoOp(OpInstall))
	m.plugins = []PluginItem{
		testPluginItem("test", "user/test", StatusNotInstalled),
	}

	result, cmd := m.Update(autoStartMsg{})
	m = result.(Model)

	if m.screen != ScreenProgress {
		t.Errorf("expected ScreenProgress after autoStartMsg, got %d", m.screen)
	}
	if cmd == nil {
		t.Error("expected non-nil command after autoStartMsg")
	}
}

func TestUpdate_SourceCompleteMsg(t *testing.T) {
	m := newTestModel(t, nil)
	result, cmd := m.Update(sourceCompleteMsg{Err: nil})
	_ = result.(Model)
	if cmd != nil {
		t.Error("expected nil command for sourceCompleteMsg")
	}
}
