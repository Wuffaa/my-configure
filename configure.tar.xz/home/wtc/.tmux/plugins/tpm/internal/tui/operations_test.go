package tui

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	tea "charm.land/bubbletea/v2"
	"github.com/tmuxpack/tpack/internal/git"
	"github.com/tmuxpack/tpack/internal/tmux"
)

func runOperationCmd(t *testing.T, cmd tea.Cmd, wantOperation Operation) ResultItem {
	t.Helper()

	got := cmd()
	msg, ok := got.(operationResultMsg)
	if !ok {
		t.Fatalf("operation command returned %T, want operationResultMsg", got)
	}
	if msg.Operation != wantOperation {
		t.Fatalf("operation = %s, want %s", msg.Operation, wantOperation)
	}
	return msg.ResultItem
}

func TestBuildInstallOpsUsesDirectoryKeyAndPreservesRaw(t *testing.T) {
	rootDir := t.TempDir()
	m := newTestModel(t, nil)
	m.cfg.PluginPath = mustRoot(t, rootDir)
	m.plugins = []PluginItem{
		{Raw: "catppuccin/tmux#v2", Name: "tmux", DirName: "tmux-87a1216f1f68", Spec: "catppuccin/tmux", Branch: "v2", Status: StatusNotInstalled},
		{Raw: "dracula/tmux alias=dark", Name: "tmux", DirName: "dark", Spec: "dracula/tmux", Status: StatusNotInstalled},
	}
	m.selected = map[int]bool{0: true, 1: true}
	m.multiSelectActive = true

	ops := m.buildInstallOps()
	if len(ops) != 2 {
		t.Fatalf("install operations = %d, want 2", len(ops))
	}
	if ops[0].Path != filepath.Join(rootDir, "tmux-87a1216f1f68") || ops[1].Path != filepath.Join(rootDir, "dark") {
		t.Fatalf("operation paths = %q, %q", ops[0].Path, ops[1].Path)
	}
	if ops[0].Raw != "catppuccin/tmux#v2" || ops[1].Raw != "dracula/tmux alias=dark" {
		t.Fatalf("operation raw specs = %q, %q", ops[0].Raw, ops[1].Raw)
	}
	if ops[0].DirName != "tmux-87a1216f1f68" || ops[1].DirName != "dark" {
		t.Fatalf("operation directory keys = %q, %q", ops[0].DirName, ops[1].DirName)
	}
}

func TestRemoveDirCmd(t *testing.T) {
	type fixture struct {
		op          pendingOp
		beforeRun   func()
		wantRemoved string
		wantKept    string
	}
	type testCase struct {
		name        string
		operation   Operation
		setup       func(*testing.T) fixture
		wantSuccess bool
		wantMessage string
		wantError   string
	}
	mkdir := func(t *testing.T, path string) {
		t.Helper()
		if err := os.MkdirAll(path, 0o755); err != nil {
			t.Fatal(err)
		}
	}

	tests := []testCase{
		{
			name:      "clean uses direct path",
			operation: OpClean,
			setup: func(t *testing.T) fixture {
				path := filepath.Join(t.TempDir(), "orphan")
				mkdir(t, path)
				return fixture{op: pendingOp{Name: "orphan", Path: path}, wantRemoved: path}
			},
			wantSuccess: true,
			wantMessage: "removed successfully",
		},
		{
			name:      "remove resolves directory key from root",
			operation: OpRemove,
			setup: func(t *testing.T) fixture {
				root := t.TempDir()
				removed := filepath.Join(root, "tmux-e74ab6318c07")
				kept := filepath.Join(root, "tmux-87a1216f1f68")
				mkdir(t, removed)
				mkdir(t, kept)
				return fixture{
					op:          pendingOp{Name: "tmux", DirName: "tmux-e74ab6318c07", Path: kept, Root: mustRoot(t, root)},
					wantRemoved: removed,
					wantKept:    kept,
				}
			},
			wantSuccess: true,
			wantMessage: "removed successfully",
		},
		{
			name:      "uninstall resolves directory key from root",
			operation: OpUninstall,
			setup: func(t *testing.T) fixture {
				root := t.TempDir()
				removed := filepath.Join(root, "plugin")
				kept := filepath.Join(root, "other")
				mkdir(t, removed)
				mkdir(t, kept)
				return fixture{
					op:          pendingOp{Name: "plugin", DirName: "plugin", Path: kept, Root: mustRoot(t, root)},
					wantRemoved: removed,
					wantKept:    kept,
				}
			},
			wantSuccess: true,
			wantMessage: "removed successfully",
		},
		{
			name:      "nonexistent directory succeeds",
			operation: OpClean,
			setup: func(t *testing.T) fixture {
				path := filepath.Join(t.TempDir(), "missing")
				return fixture{op: pendingOp{Name: "ghost", Path: path}, wantRemoved: path}
			},
			wantSuccess: true,
			wantMessage: "removed successfully",
		},
		{
			name:      "invalid root fails closed",
			operation: OpRemove,
			setup: func(t *testing.T) fixture {
				kept := filepath.Join(t.TempDir(), "plugin")
				mkdir(t, kept)
				return fixture{op: pendingOp{Name: "plugin", DirName: "plugin", Path: kept}, wantKept: kept}
			},
			wantMessage: `invalid plugin path from zero value "": path is empty`,
		},
		{
			name:      "unsupported operation fails closed",
			operation: OpInstall,
			setup: func(t *testing.T) fixture {
				root := t.TempDir()
				kept := filepath.Join(root, "plugin")
				mkdir(t, kept)
				return fixture{
					op:       pendingOp{Name: "plugin", DirName: "plugin", Path: kept, Root: mustRoot(t, root)},
					wantKept: kept,
				}
			},
			wantMessage: "unsupported directory removal operation: 1",
		},
	}
	for _, operation := range []Operation{OpRemove, OpUninstall} {
		tests = append(tests, testCase{
			name:      operation.String() + " resolves root immediately before removal",
			operation: operation,
			setup: func(t *testing.T) fixture {
				base := t.TempDir()
				pluginRoot := filepath.Join(base, "real-plugins")
				kept := filepath.Join(pluginRoot, "repo")
				mkdir(t, kept)
				rootLink := filepath.Join(base, "plugins")
				if err := os.Symlink(pluginRoot, rootLink); err != nil {
					t.Fatal(err)
				}
				return fixture{
					op: pendingOp{Name: "repo", DirName: "repo", Path: kept, Root: mustRoot(t, rootLink)},
					beforeRun: func() {
						if err := os.Remove(rootLink); err != nil {
							t.Fatal(err)
						}
					},
					wantKept: kept,
				}
			},
			wantError: "resolve plugin root",
		})
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fixture := tt.setup(t)
			cmd := removeDirCmd(tt.operation, fixture.op)
			if fixture.beforeRun != nil {
				fixture.beforeRun()
			}
			result := runOperationCmd(t, cmd, tt.operation)
			if result.Success != tt.wantSuccess {
				t.Fatalf("success = %t, want %t: %#v", result.Success, tt.wantSuccess, result)
			}
			if result.Name != fixture.op.Name || result.DirName != fixture.op.DirName {
				t.Fatalf("result identity = %q/%q, want %q/%q", result.Name, result.DirName, fixture.op.Name, fixture.op.DirName)
			}
			if tt.wantMessage != "" && result.Message != tt.wantMessage {
				t.Fatalf("message = %q, want %q", result.Message, tt.wantMessage)
			}
			if tt.wantError != "" && !strings.Contains(result.Message, tt.wantError) {
				t.Fatalf("message = %q, want substring %q", result.Message, tt.wantError)
			}
			if fixture.wantRemoved != "" {
				if _, err := os.Stat(fixture.wantRemoved); !os.IsNotExist(err) {
					t.Fatalf("path %q was not removed: %v", fixture.wantRemoved, err)
				}
			}
			if fixture.wantKept != "" {
				if _, err := os.Stat(fixture.wantKept); err != nil {
					t.Fatalf("path %q was changed: %v", fixture.wantKept, err)
				}
			}
		})
	}
}

func TestStartRemoveUsesRawConfigDeclaration(t *testing.T) {
	rootDir := t.TempDir()
	confPath := filepath.Join(t.TempDir(), "tmux.conf")
	const raw = "catppuccin/tmux alias=catppuccin#v2"
	if err := os.WriteFile(confPath, []byte("set -g @plugin \""+raw+"\"\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	m := newTestModel(t, nil)
	m.cfg.PluginPath = mustRoot(t, rootDir)
	m.cfg.TmuxConf = confPath
	m.plugins = []PluginItem{{Raw: raw, Name: "catppuccin", DirName: "catppuccin", Spec: "catppuccin/tmux", Branch: "v2", Status: StatusInstalled}}

	_, cmd := m.startOperation(OpRemove)
	if cmd == nil {
		t.Fatal("remove did not queue filesystem operation")
	}
	data, err := os.ReadFile(confPath)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(data), raw) {
		t.Fatalf("raw config declaration was not removed:\n%s", data)
	}
}

func TestInstallPluginCmd_Success(t *testing.T) {
	cloner := git.NewMockCloner()
	op := pendingOp{
		Name: "test-plugin",
		Spec: "user/test-plugin",
		Path: t.TempDir() + "/test-plugin/",
	}

	result := runOperationCmd(t, installPluginCmd(cloner, op), OpInstall)
	if !result.Success {
		t.Errorf("expected success, got failure: %s", result.Message)
	}
	if result.Name != "test-plugin" {
		t.Errorf("expected name test-plugin, got %s", result.Name)
	}
}

func TestInstallPluginCmd_Failure(t *testing.T) {
	cloner := git.NewMockCloner()
	cloner.Err = errors.New("clone failed")
	op := pendingOp{
		Name: "test-plugin",
		Spec: "user/test-plugin",
		Path: t.TempDir() + "/test-plugin/",
	}

	result := runOperationCmd(t, installPluginCmd(cloner, op), OpInstall)
	if result.Success {
		t.Error("expected failure, got success")
	}
}

func TestUpdatePluginCmd_Success(t *testing.T) {
	puller := git.NewMockPuller()
	puller.Output = "Already up to date."
	revParser := git.NewMockRevParser()
	revParser.Hash = "abc123"
	logger := git.NewMockLogger()
	dir := t.TempDir()
	op := pendingOp{
		Name: "test-plugin",
		Path: dir + "/",
	}

	result := runOperationCmd(t, updatePluginCmd(puller, revParser, logger, op), OpUpdate)
	if !result.Success {
		t.Errorf("expected success, got failure: %s", result.Message)
	}
	if result.Output != "Already up to date." {
		t.Errorf("expected output 'Already up to date.', got %q", result.Output)
	}
	// Same hash before/after → no commits.
	if len(result.Commits) != 0 {
		t.Errorf("expected 0 commits when hash unchanged, got %d", len(result.Commits))
	}
}

func TestUpdatePluginCmd_WithCommits(t *testing.T) {
	puller := git.NewMockPuller()
	puller.Output = "Updating abc..def"

	callCount := 0
	revParser := &sequentialMockRevParser{
		hashes: []string{"abc123", "def456"},
		count:  &callCount,
	}
	logger := git.NewMockLogger()
	logger.Commits = []git.Commit{
		{Hash: "def456", Message: "add feature"},
		{Hash: "ccc333", Message: "fix bug"},
	}

	op := pendingOp{
		Name: "test-plugin",
		Path: t.TempDir() + "/",
	}

	result := runOperationCmd(t, updatePluginCmd(puller, revParser, logger, op), OpUpdate)
	if !result.Success {
		t.Errorf("expected success, got failure: %s", result.Message)
	}
	if len(result.Commits) != 2 {
		t.Fatalf("expected 2 commits, got %d", len(result.Commits))
	}
	if result.Commits[0].Hash != "def456" {
		t.Errorf("expected first commit hash def456, got %s", result.Commits[0].Hash)
	}
	if result.Dir != op.Path {
		t.Errorf("expected Dir=%q, got %q", op.Path, result.Dir)
	}
	if result.BeforeRef != "abc123" {
		t.Errorf("expected BeforeRef=abc123, got %q", result.BeforeRef)
	}
	if result.AfterRef != "def456" {
		t.Errorf("expected AfterRef=def456, got %q", result.AfterRef)
	}
}

func TestUpdatePluginCmd_NilRevParser(t *testing.T) {
	puller := git.NewMockPuller()
	puller.Output = "Already up to date."

	op := pendingOp{
		Name: "test-plugin",
		Path: t.TempDir() + "/",
	}

	result := runOperationCmd(t, updatePluginCmd(puller, nil, nil, op), OpUpdate)
	if !result.Success {
		t.Errorf("expected success, got failure: %s", result.Message)
	}
	if len(result.Commits) != 0 {
		t.Errorf("expected 0 commits with nil revParser, got %d", len(result.Commits))
	}
}

func TestUpdatePluginCmd_Failure(t *testing.T) {
	puller := git.NewMockPuller()
	puller.Err = errors.New("pull failed")
	op := pendingOp{
		Name: "test-plugin",
		Path: t.TempDir() + "/",
	}

	result := runOperationCmd(t, updatePluginCmd(puller, nil, nil, op), OpUpdate)
	if result.Success {
		t.Error("expected failure, got success")
	}
}

// sequentialMockRevParser returns different hashes on sequential calls.
type sequentialMockRevParser struct {
	hashes []string
	count  *int
}

func (s *sequentialMockRevParser) RevParse(_ context.Context, _ string) (string, error) {
	idx := *s.count
	*s.count++
	if idx < len(s.hashes) {
		return s.hashes[idx], nil
	}
	return "unknown", nil
}

func TestBuildCleanOpsUsesOrphanDirectoryKey(t *testing.T) {
	m := newTestModel(t, nil)
	m.orphans = []OrphanItem{{
		Name: "display label", DirName: "orphan-directory", Path: "/plugins/orphan-directory",
	}}

	ops := m.buildCleanOps()

	if len(ops) != 1 || ops[0].Name != "display label" || ops[0].DirName != "orphan-directory" {
		t.Fatalf("clean operations = %+v", ops)
	}
}

func TestBuildRemoveOps(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusInstalled),
		testPluginItem("b", "user/b", StatusNotInstalled),
		testPluginItem("c", "user/c", StatusInstalled),
	}
	m.listScroll.cursor = 1

	ops := m.buildRemoveOps()
	if len(ops) != 1 {
		t.Fatalf("expected 1 remove op (cursor), got %d", len(ops))
	}
	if ops[0].Name != "b" {
		t.Errorf("expected op name 'b', got %s", ops[0].Name)
	}
}

func TestBuildRemoveOps_IncludesAllStatuses(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusInstalled),
		testPluginItem("b", "user/b", StatusNotInstalled),
	}
	m.selected = map[int]bool{0: true, 1: true}
	m.multiSelectActive = true

	ops := m.buildRemoveOps()
	if len(ops) != 2 {
		t.Errorf("expected 2 remove ops (both statuses), got %d", len(ops))
	}
}

func TestBuildUninstallOps(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusInstalled),
		testPluginItem("b", "user/b", StatusNotInstalled),
		testPluginItem("c", "user/c", StatusInstalled),
	}
	m.listScroll.cursor = 0

	ops := m.buildUninstallOps()
	if len(ops) != 1 {
		t.Errorf("expected 1 uninstall op (cursor on installed), got %d", len(ops))
	}
	if ops[0].Name != "a" {
		t.Errorf("expected op name 'a', got %s", ops[0].Name)
	}
}

func TestBuildUninstallOps_SkipsNotInstalled(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusNotInstalled),
	}
	m.listScroll.cursor = 0

	ops := m.buildUninstallOps()
	if len(ops) != 0 {
		t.Errorf("expected 0 uninstall ops for not-installed plugin, got %d", len(ops))
	}
}

func TestDestructiveOpsRejectRootSymlinkBeforeScheduling(t *testing.T) {
	rootLink := filepath.Join(t.TempDir(), "plugins")
	if err := os.Symlink(string(filepath.Separator), rootLink); err != nil {
		t.Fatal(err)
	}

	tests := []struct {
		name  string
		build func(*Model) []pendingOp
	}{
		{name: "remove", build: (*Model).buildRemoveOps},
		{name: "uninstall", build: (*Model).buildUninstallOps},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			m := newTestModel(t, nil)
			m.cfg.PluginPath = mustRoot(t, rootLink)
			m.plugins = []PluginItem{testPluginItem("repo", "user/repo", StatusInstalled)}

			if ops := tt.build(&m); len(ops) != 0 {
				t.Fatalf("scheduled %d destructive operations through root symlink", len(ops))
			}
			if m.plugins[0].Status != StatusLoadFailed {
				t.Fatalf("status = %v, want %v", m.plugins[0].Status, StatusLoadFailed)
			}
		})
	}
}

func TestBuildInstallOps(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusNotInstalled),
		testPluginItem("b", "user/b", StatusInstalled),
		testPluginItem("c", "user/c", StatusNotInstalled),
	}
	m.listScroll.cursor = 0

	ops := m.buildInstallOps()
	if len(ops) != 1 {
		t.Errorf("expected 1 install op (cursor on not-installed), got %d", len(ops))
	}
}

func TestBuildInstallOps_MultiSelect(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusNotInstalled),
		testPluginItem("b", "user/b", StatusInstalled),
		testPluginItem("c", "user/c", StatusNotInstalled),
	}
	m.selected = map[int]bool{0: true, 2: true}
	m.multiSelectActive = true

	ops := m.buildInstallOps()
	if len(ops) != 2 {
		t.Errorf("expected 2 install ops, got %d", len(ops))
	}
}

func TestBuildUpdateOps_AllInstalled(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusInstalled),
		testPluginItem("b", "user/b", StatusInstalled),
	}
	m.listScroll.cursor = 0

	ops := m.buildUpdateOps()
	// Cursor on installed plugin → 1 op. But if nothing selected and cursor match
	// is installed, it returns just cursor. Then fallback to all installed.
	if len(ops) != 1 {
		t.Errorf("expected 1 update op (cursor), got %d", len(ops))
	}
}

func TestDispatchNext_EmptyQueue(t *testing.T) {
	m := newTestModel(t, nil)
	m.pendingItems = nil

	cmd := m.dispatchNext()
	if cmd != nil {
		t.Error("expected nil cmd for empty queue")
	}
	if m.processing {
		t.Error("expected processing to be false")
	}
}

func TestBuildAutoInstallOps(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusNotInstalled),
		testPluginItem("b", "user/b", StatusInstalled),
		testPluginItem("c", "user/c", StatusNotInstalled),
	}

	ops := m.buildAutoInstallOps()
	if len(ops) != 2 {
		t.Errorf("expected 2 auto install ops, got %d", len(ops))
	}
	if ops[0].Name != "a" {
		t.Errorf("expected first op name 'a', got %s", ops[0].Name)
	}
	if ops[1].Name != "c" {
		t.Errorf("expected second op name 'c', got %s", ops[1].Name)
	}
}

func TestBuildAutoInstallOps_NoneNotInstalled(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusInstalled),
	}

	ops := m.buildAutoInstallOps()
	if len(ops) != 0 {
		t.Errorf("expected 0 auto install ops, got %d", len(ops))
	}
}

func TestBuildAutoUpdateOps(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusInstalled),
		testPluginItem("b", "user/b", StatusNotInstalled),
		testPluginItem("c", "user/c", StatusOutdated),
		testPluginItem("d", "user/d", StatusChecking),
	}

	ops := m.buildAutoUpdateOps()
	if len(ops) != 3 {
		t.Errorf("expected 3 auto update ops (installed+outdated+checking), got %d", len(ops))
	}
}

func TestBuildAutoUpdateOps_NoneInstalled(t *testing.T) {
	m := newTestModel(t, nil)
	m.plugins = []PluginItem{
		testPluginItem("a", "user/a", StatusNotInstalled),
	}

	ops := m.buildAutoUpdateOps()
	if len(ops) != 0 {
		t.Errorf("expected 0 auto update ops, got %d", len(ops))
	}
}

func TestDispatchNext_WithRunner_SourcesOnInstall(t *testing.T) {
	runner := tmux.NewMockRunner()
	m := newTestModel(t, nil)
	m.cfg.TmuxConf = "/tmp/test.conf"
	m.deps.Runner = runner
	m.operation = OpInstall
	m.pendingItems = nil

	cmd := m.dispatchNext()
	if cmd == nil {
		t.Fatal("expected source command when runner is set and install completes")
	}

	// Execute the command and verify it calls SourceFile.
	msg := cmd()
	if _, ok := msg.(sourceCompleteMsg); !ok {
		t.Fatalf("expected sourceCompleteMsg, got %T", msg)
	}

	found := false
	for _, c := range runner.Calls {
		if c.Method == "SourceFile" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected SourceFile to be called")
	}
}

func TestDispatchNext_WithRunner_SourcesOnUpdate(t *testing.T) {
	runner := tmux.NewMockRunner()
	m := newTestModel(t, nil)
	m.cfg.TmuxConf = "/tmp/test.conf"
	m.deps.Runner = runner
	m.operation = OpUpdate
	m.pendingItems = nil

	cmd := m.dispatchNext()
	if cmd == nil {
		t.Fatal("expected source command when runner is set and update completes")
	}
}

func TestDispatchNext_WithRunner_NoSourceOnClean(t *testing.T) {
	runner := tmux.NewMockRunner()
	m := newTestModel(t, nil)
	m.cfg.TmuxConf = "/tmp/test.conf"
	m.deps.Runner = runner
	m.operation = OpClean
	m.pendingItems = nil

	cmd := m.dispatchNext()
	if cmd != nil {
		t.Error("expected nil command for clean operation (no sourcing needed)")
	}
}

func TestDispatchNext_NoRunner_NoSource(t *testing.T) {
	m := newTestModel(t, nil)
	m.operation = OpInstall
	m.pendingItems = nil

	cmd := m.dispatchNext()
	if cmd != nil {
		t.Error("expected nil command when no runner is set")
	}
}

func TestSourceCmd(t *testing.T) {
	runner := tmux.NewMockRunner()
	cmd := sourceCmd(runner, "/tmp/test.conf")
	msg := cmd()

	result, ok := msg.(sourceCompleteMsg)
	if !ok {
		t.Fatalf("expected sourceCompleteMsg, got %T", msg)
	}
	if result.Err != nil {
		t.Errorf("expected nil error, got %v", result.Err)
	}

	if len(runner.Calls) != 1 {
		t.Fatalf("expected 1 call, got %d", len(runner.Calls))
	}
	if runner.Calls[0].Method != "SourceFile" {
		t.Errorf("expected SourceFile call, got %s", runner.Calls[0].Method)
	}
	if runner.Calls[0].Args[0] != "/tmp/test.conf" {
		t.Errorf("expected conf path /tmp/test.conf, got %s", runner.Calls[0].Args[0])
	}
}

func TestDispatchNext_BatchesUpToMax(t *testing.T) {
	m := newTestModel(t, nil)
	m.operation = OpInstall
	m.processing = true
	m.inFlight = 0
	m.pendingItems = make([]pendingOp, 5)
	for i := range m.pendingItems {
		m.pendingItems[i] = pendingOp{
			Name: fmt.Sprintf("plugin-%d", i),
			Spec: fmt.Sprintf("user/plugin-%d", i),
			Path: t.TempDir() + "/",
		}
	}

	cmd := m.dispatchNext()
	if cmd == nil {
		t.Fatal("expected non-nil command from dispatchNext")
	}
	if m.inFlight != maxConcurrentOps {
		t.Errorf("expected inFlight=%d, got %d", maxConcurrentOps, m.inFlight)
	}
	if len(m.pendingItems) != 5-maxConcurrentOps {
		t.Errorf("expected %d remaining pending, got %d", 5-maxConcurrentOps, len(m.pendingItems))
	}
	if len(m.inFlightNames) != maxConcurrentOps {
		t.Errorf("expected %d inFlightNames, got %d", maxConcurrentOps, len(m.inFlightNames))
	}
}

func TestDispatchNext_RespectsInFlightLimit(t *testing.T) {
	m := newTestModel(t, nil)
	m.operation = OpInstall
	m.processing = true
	m.inFlight = maxConcurrentOps
	m.pendingItems = []pendingOp{
		{Name: "extra", Spec: "user/extra", Path: t.TempDir() + "/"},
	}

	cmd := m.dispatchNext()
	if cmd != nil {
		t.Error("expected nil command when at concurrency limit")
	}
	if len(m.pendingItems) != 1 {
		t.Errorf("expected pending items unchanged, got %d", len(m.pendingItems))
	}
}

func TestHandleOperationResult_DispatchesMore(t *testing.T) {
	m := newTestModel(t, nil)
	m.operation = OpInstall
	m.processing = true
	m.inFlight = maxConcurrentOps
	m.inFlightNames = make([]string, maxConcurrentOps)
	for i := range m.inFlightNames {
		m.inFlightNames[i] = fmt.Sprintf("inflight-%d", i)
	}
	m.totalItems = maxConcurrentOps + 2
	m.completedItems = 0
	m.pendingItems = []pendingOp{
		{Name: "next-a", Spec: "user/next-a", Path: t.TempDir() + "/"},
		{Name: "next-b", Spec: "user/next-b", Path: t.TempDir() + "/"},
	}

	result := ResultItem{Name: m.inFlightNames[0], Success: true, Message: "installed"}
	updated, cmd := m.Update(operationResultMsg{Operation: OpInstall, ResultItem: result})
	m = updated.(Model)

	if m.inFlight != maxConcurrentOps {
		t.Errorf("expected inFlight to refill to %d, got %d", maxConcurrentOps, m.inFlight)
	}
	if cmd == nil {
		t.Error("expected non-nil command to dispatch next batch")
	}
	if m.completedItems != 1 {
		t.Errorf("expected completedItems=1, got %d", m.completedItems)
	}
	// The completed item should be removed from inFlightNames.
	for _, name := range m.inFlightNames {
		if name == result.Name {
			t.Errorf("expected %q removed from inFlightNames", result.Name)
		}
	}
}
