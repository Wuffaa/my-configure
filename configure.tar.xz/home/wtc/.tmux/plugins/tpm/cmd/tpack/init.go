package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"

	"github.com/spf13/cobra"
	"github.com/tmuxpack/tpack/internal/config"
	"github.com/tmuxpack/tpack/internal/shell"
	"github.com/tmuxpack/tpack/internal/state"
	"github.com/tmuxpack/tpack/internal/tmux"
	"github.com/tmuxpack/tpack/internal/tui"
	"github.com/tmuxpack/tpack/internal/ui"
)

var initCmd = &cobra.Command{
	Use:   "init",
	Short: "Initialize tpack, bind keys, and source plugins",
	RunE: func(cmd *cobra.Command, args []string) error {
		return runInitCmd()
	},
}

func runInitCmd() error {
	runner := tmux.NewRealRunner()
	shell := ui.NewShellSink(os.Stdout, os.Stderr)
	status := ui.NewStatusSink(runner)
	// init usually runs from the tmux.conf `run` line, where stderr is
	// invisible; the status line is the only channel the user sees.
	output := newInitOutput(shell, status)
	return runInit(runner, output)
}

func runInit(runner tmux.Runner, output ui.Output) error {
	// Check tmux version.
	verStr, err := runner.Version()
	if err != nil {
		output.Err("failed to get tmux version")
		return outputResult(output)
	}
	current := tmux.ParseVersionDigits(verStr)
	if !tmux.IsVersionSupported(current, config.SupportedTmuxVersion) {
		// TODO: add e2e tests with version 1.9
		output.Err("Tmux version unsupported! Please install Tmux version 1.9 or greater!")
		return outputResult(output)
	}

	// Resolve config.
	cfg, err := config.Resolve(runner)
	if err != nil {
		output.Err("config: " + err.Error())
		return outputResult(output)
	}
	plugins, err := loadPlugins(runner, cfg, output)
	if err != nil {
		output.Err("config: " + err.Error())
		return outputResult(output)
	}

	// Set plugin path in tmux environment (set both for compatibility).
	if setErr := runner.SetEnvironment(config.PluginPathEnvVar, cfg.PluginPath.String()); setErr != nil {
		output.Warn("failed to set " + config.PluginPathEnvVar + ": " + setErr.Error())
	}
	if setErr := runner.SetEnvironment(config.LegacyPluginPathEnvVar, cfg.PluginPath.String()); setErr != nil {
		output.Warn("failed to set " + config.LegacyPluginPathEnvVar + ": " + setErr.Error())
	}

	binary := findBinary()
	if bindErr := bindKeys(runner, cfg, binary); bindErr != nil {
		output.Warn("failed to bind keys: " + bindErr.Error())
	}

	// Source plugins; failures go to stderr and are persisted for the TUI.
	mgr := newManagerDeps(cfg.PluginPath, output)
	failures := mgr.Source(context.Background(), plugins)
	for _, f := range failures {
		output.Err("error loading " + f.Name + ": " + f.Message)
	}
	if err := state.SaveLoadErrors(cfg.StatePath, failures); err != nil {
		output.Warn("failed to save load errors: " + err.Error())
	}

	if shouldSpawnUpdateCheck(cfg) {
		spawnUpdateCheck(binary, output)
	}

	if shouldSpawnSelfUpdate(binary, cfg.PluginPath.String(), cfg.PinnedVersion) {
		spawnSelfUpdate(binary, output)
	}

	return outputResult(output)
}

func newInitOutput(shell, status ui.Sink) ui.Output {
	warnAndError := ui.NewMultiSink(shell, status)
	return ui.NewReporter(ui.NewSeveritySink(shell, warnAndError, warnAndError))
}

func bindKeys(runner tmux.Runner, cfg *config.Config, binary string) error {
	verStr, err := runner.Version()
	if err == nil && popupSupported(verStr) {
		return bindPopupKeys(runner, cfg, binary)
	}
	return bindInlineKeys(runner, cfg, binary)
}

// tuiShellCmd builds a shell command that runs the TUI with the given flags.
// Both binary and flags are shell-quoted for safe embedding in nested shell contexts.
func tuiShellCmd(binary, flags string) string {
	cmd := "PATH=" + shell.Quote(os.Getenv("PATH")) + " " + shell.Quote(binary) + " tui"
	if flags != "" {
		cmd += " " + flags
	}
	return cmd
}

// bindPopupKeys binds keys using display-popup for tmux >= 3.2.
// Falls back to new-window if the popup cannot open (e.g. terminal too small).
func bindPopupKeys(runner tmux.Runner, cfg *config.Config, binary string) error {
	build := func(flags string) string {
		quoted := shell.Quote(tuiShellCmd(binary, flags))
		popup := fmt.Sprintf("tmux display-popup -E -w %d -h %d %s",
			tui.FixedWidth, tui.FixedHeight, quoted)
		fallback := "tmux new-window " + quoted
		return popup + " 2>/dev/null || " + fallback
	}

	return errors.Join(
		runner.BindKey(cfg.InstallKey, build("--install"), "[tpack] Install plugins"),
		runner.BindKey(cfg.UpdateKey, build("--update"), "[tpack] Update plugins"),
		runner.BindKey(cfg.CleanKey, build("--clean"), "[tpack] Clean plugins"),
		runner.BindKey(cfg.TuiKey, build(""), "[tpack] Open TUI"),
	)
}

// bindInlineKeys binds keys for tmux < 3.2 (no popup support).
// Uses new-window to ensure the TUI has a controlling terminal.
func bindInlineKeys(runner tmux.Runner, cfg *config.Config, binary string) error {
	build := func(flags string) string {
		return "tmux new-window " + shell.Quote(tuiShellCmd(binary, flags))
	}

	return errors.Join(
		runner.BindKey(cfg.InstallKey, build("--install"), "[tpack] Install plugins"),
		runner.BindKey(cfg.UpdateKey, build("--update"), "[tpack] Update plugins"),
		runner.BindKey(cfg.CleanKey, build("--clean"), "[tpack] Clean plugins"),
		runner.BindKey(cfg.TuiKey, build(""), "[tpack] Open TUI"),
	)
}

// Reports whether the binary is at the auto-download location.
func isAutoDownloaded(binary, pluginPath string) bool {
	expected := filepath.Join(pluginPath, "tpm", binaryName)
	return binary == expected
}

// Reports whether the self-update check should run.
func shouldSpawnSelfUpdate(binary, pluginPath, pinnedVersion string) bool {
	return isAutoDownloaded(binary, pluginPath) && pinnedVersion == ""
}

// Launches `tpack self-update` as a detached background process.
func spawnSelfUpdate(binary string, out ui.Output) {
	cmd := exec.Command(binary, "self-update") //nolint:noctx // intentionally detached, no cancellation
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	cmd.Stdout = nil
	cmd.Stderr = nil
	if err := cmd.Start(); err != nil {
		out.Warn("failed to spawn self-update: " + err.Error())
	}
}

// Returns true if update checks are configured.
func shouldSpawnUpdateCheck(cfg *config.Config) bool {
	return cfg.UpdateMode != "" && cfg.UpdateMode != updateModeOff && cfg.UpdateCheckInterval > 0
}

// Launches `tpack check-updates` as a detached background process.
func spawnUpdateCheck(binary string, out ui.Output) {
	cmd := exec.Command(binary, "check-updates") //nolint:noctx // intentionally detached, no cancellation
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	cmd.Stdout = nil
	cmd.Stderr = nil
	if err := cmd.Start(); err != nil {
		out.Warn("failed to spawn update check: " + err.Error())
	}
}

// Returns the absolute path to the tpack binary.
func findBinary() string {
	// Try the executable path first.
	exe, err := os.Executable()
	if err == nil {
		resolved, err := filepath.EvalSymlinks(exe)
		if err == nil {
			return resolved
		}
		return exe
	}
	// Fallback: try to find alongside the tpm script.
	if dir := os.Getenv("CURRENT_DIR"); dir != "" {
		candidate := filepath.Join(dir, binaryName)
		if _, err := os.Stat(candidate); err == nil { //nolint:gosec // candidate is built from filepath.Join with a constant binary name
			return candidate
		}
	}
	return binaryName
}
