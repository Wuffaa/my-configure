---
hide:
  - navigation
  - toc
---

# tpack

**A modern tmux plugin manager written in Go.**
Compatible with TPM configuration syntax and key bindings, with a
repository-aware on-disk layout.

Works on Linux, macOS, and FreeBSD.

---

## Features

<div class="grid cards" markdown>

-   **TPM-Compatible Configuration**

    Existing TPM settings, plugin declarations, and key bindings continue to
    work. Exact-origin legacy plugin directories are migrated once; see the
    [migration guide](getting-started/migrating-from-tpm.md).

-   **Interactive TUI**

    Browse, install, update, and clean plugins with a built-in terminal UI. Launches in a tmux popup on 3.2+.

-   **Plugin Registry**

    Discover plugins from a curated registry. Search by name, filter by category, and install with a single key press — no manual config editing required.

-   **Automatic Updates**

    Background plugin update checking with three modes: prompt, auto, or off. Self-update support for the tpack binary itself.

-   **Multiple Install Methods**

    Available via Homebrew, AUR, deb/rpm packages, git clone, or build from source.

</div>

## Quick Start

=== "Standalone binary"

    Install tpack and add it to your tmux config:

    ```bash
    # Install (macOS / Linux)
    brew install tmuxpack/tpack/tpack
    ```

    ```bash
    # ~/.tmux.conf
    set -g @plugin 'tmux-plugins/tmux-sensible'

    # Initialize tpack (keep this line at the very bottom of tmux.conf)
    run 'tpack init'
    ```

=== "Git clone (TPM-compatible)"

    Clone tpack and add it to your tmux config:

    ```bash
    git clone https://github.com/tmuxpack/tpack ~/.tmux/plugins/tpm
    ```

    ```bash
    # ~/.tmux.conf
    set -g @plugin 'tmux-plugins/tmux-sensible'

    # Initialize tpack (keep this line at the very bottom of tmux.conf)
    run '~/.tmux/plugins/tpm/tpm'
    ```

Reload tmux and press ++prefix+shift+i++ to install plugins:

```bash
tmux source ~/.tmux.conf
```

See the [installation guide](getting-started/installation.md) for all install methods.
