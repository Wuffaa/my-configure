# Managing Plugins

tpack binds three key combinations in tmux for the core plugin lifecycle. Each opens the TUI with the corresponding operation pre-selected.

## Discovering plugins

Open the TUI with ++prefix+shift+t++ and press ++b++ to browse a curated plugin registry. You can filter by category with ++tab++ and search by name with ++slash++. Select a plugin and press ++i++ to install it — the plugin line is added to your `tmux.conf` automatically.

See [Interactive TUI — Browse Screen](interactive-tui.md#browse-screen) for the full keybinding reference.

## Installing plugins

1. Add a plugin line to your tmux config:

    ```bash
    set -g @plugin 'tmux-plugins/tmux-sensible'
    ```

2. Press ++prefix+shift+i++ (capital I, as in **I**nstall).

3. The plugin is cloned to your plugin directory (see [Plugin Directory](../configuration/plugin-directory.md)) and sourced automatically.

!!! tip
    You can also install plugins directly from the [browse screen](interactive-tui.md#browse-screen) without manually editing your config.

## Pinning a plugin

Append `#<ref>` to pin a plugin to a tag or commit SHA. Pinned plugins are not fast-forwarded on update.

```tmux
set -g @plugin 'catppuccin/tmux#v2.1.3'
set -g @plugin 'tmux-plugins/tmux-sensible#abc1234'
```

To move to a new version, edit the ref in your config and run an update.

## Updating plugins

Press ++prefix+shift+u++ to update plugins. The TUI opens and you can select which plugins to update.

## Removing plugins

To completely remove a plugin (delete both the directory and the config entry), select it in the TUI and press ++r++. This is the quickest way to get rid of a plugin you no longer want — no manual config editing required.

## Uninstalling plugins

To uninstall a plugin while keeping its entry in your config, select it in the TUI and press ++x++. The plugin directory is deleted but the `@plugin` line stays in your `tmux.conf`, so the plugin appears as "Not Installed" and can be reinstalled later with ++i++.

## Cleaning orphaned directories

If you manually remove a plugin line from your config, the plugin directory may still exist on disk. Press ++prefix+alt+u++ or use `tpack clean` to remove these orphaned directories. In the TUI, press ++c++ to run the same cleanup.

If your config declares no plugins at all (but is still readable), `clean` removes everything installed — see the FAQ entry [Why does clean remove everything when I removed all @plugin lines?](../troubleshooting/faq.md#why-does-clean-remove-everything-when-i-removed-all-plugin-lines).

!!! note "Remove vs Uninstall vs Clean"
    | Operation | Deletes directory | Removes from config | Plugin stays in list |
    |-----------|:-:|:-:|:-:|
    | **Remove** (++r++) | Yes | Yes | No |
    | **Uninstall** (++x++) | Yes | No | Yes (as "Not Installed") |
    | **Clean** (++c++) | Yes | N/A (already not in config) | N/A |

!!! tip
    All key bindings can be customized. See [Key Bindings](../configuration/key-bindings.md) for details.
