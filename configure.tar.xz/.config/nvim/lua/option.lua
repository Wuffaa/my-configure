--vim基本配置
--编辑和保存文件所使用的编码
vim.opt.fileencodings = { 'utf-8', 'gbk', 'gb2312', 'gb18030', 'latin-1' }
--新建文件所使用的编码
vim.opt.fileencoding = 'utf-8'
--vim的缓冲区、菜单文本和消息文本使用的编码
vim.opt.encoding = 'utf-8'
--设置tab长度为4空格
vim.opt.tabstop = 4
vim.opt.shiftwidth = 4
vim.opt.softtabstop = 4
vim.opt.expandtab = true
vim.opt.autoindent = true
vim.opt.smartindent = true
--显示行号
vim.opt.nu = true
--显示相对行号
vim.opt.relativenumber = true
--1=启动显示状态行、2=总是显示状态行 3=全局状态栏（statusline 只在屏幕底部显示一次）
vim.opt.laststatus = 3
--输入字符串就显示匹配点
vim.opt.incsearch = true
--光标上下保留行
vim.opt.scrolloff = 8
--光标左右保留列
vim.opt.sidescrolloff = 8
--禁用鼠标
vim.opt.mouse = ''
vim.g.mapleader = " "
vim.opt.termguicolors = true
vim.wo.foldlevel = 99
vim.wo.foldmethod = 'expr'
vim.wo.foldexpr = 'v:lua.vim.treesitter.foldexpr()'
vim.opt.winborder = 'rounded'
vim.opt.swapfile = false

-- neovide配置
vim.g.neovide_no_ext_cmdline = true
vim.g.neovide_no_ext_messages = true
vim.opt.linespace = 0
vim.opt.clipboard:append 'unnamedplus'
vim.g.neovide_title_background_color = string.format(
    "%x",
    vim.api.nvim_get_hl(0, {id=vim.api.nvim_get_hl_id_by_name("Normal")}).bg
)
vim.g.neovide_tiele_text_color = "pink"
vim.g.neovide_window_blurred = true
vim.g.neovide_floating_animation = true
vim.g.neovide_floating_blur_amount_x = 1.5
vim.g.neovide_floating_blur_amount_y = 1.5
vim.g.neovide_floating_shadow = false
vim.g.experimental_layer_grouping = false
vim.g.neovide_opacity = 0.7
vim.g.neovide_normal_opacity = 0.7
vim.g.neovide_theme = 'dark'
vim.g.neovide_detach_on_quit = 'always_detach'
vim.g.neovide_cursor_vfx_mode = "pixiedust"
vim.g.neovide_cursor_vfx_particle_lifetime = 2
vim.g.neovide_cursor_vfx_particle_density = 4
vim.g.neovide_fullscreen = false
vim.g.neovide_scale_factor = 1.0
vim.g.neovide_hide_mouse_when_typing = true
vim.g.neovide_remember_window_size = true
vim.g.neovide_position_animation_length = 0.3
vim.o.guifont = "JetBrainsMono Nerd Font:h12"

-- 缩进配置
vim.api.nvim_create_autocmd('FileType', {
  pattern = { 'lua', 'javascript', 'typescript', 'html', 'css', 'json', 'yaml' },
  callback = function()
    vim.bo.shiftwidth = 2
    vim.bo.tabstop = 2
    vim.bo.softtabstop = 2
  end,
})
