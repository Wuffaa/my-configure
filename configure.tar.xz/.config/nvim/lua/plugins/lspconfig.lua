return {
  "neovim/nvim-lspconfig",
  config = function()
    vim.lsp.enable({"clangd", "pyright", "marksman", "bashls", "jsonls", "dockerls"})
  end,
}
