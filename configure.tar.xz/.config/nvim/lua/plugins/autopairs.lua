return {
  'windwp/nvim-autopairs',
  event = 'InsertEnter',
  config = true,
  opts = {
    map_c_h = true, -- Map the <C-h> key to delete a pair
  } -- this is equalent to setup({}) function
}
