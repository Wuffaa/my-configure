return {
  "hedyhli/outline.nvim",
  lazy = true,
  cmd = { "Outline" },
  opts = {
    outline_window = {
      split_command = 'botright 35vsp',
      hide_cursor = true,
    },
  },
  keys = {
    {"<leader><tab>", "<cmd>Outline<CR>", desc = "Toggle Outline"},
  }
}
