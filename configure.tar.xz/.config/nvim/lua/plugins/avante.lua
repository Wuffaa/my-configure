return {
  "yetone/avante.nvim",
  build = "make",
  build_timeout = 3000,
  event = "VeryLazy",
  dependencies = {
    "nvim-lua/plenary.nvim",
    "MunifTanjim/nui.nvim",
  },
  ---@module 'avante'
  ---@type avante.Config
  opts = {
    -- 在此处添加任何选项
    -- 例如
    provider = "deepseek",
    providers = {
      deepseek = {
        __inherited_from = "openai",
        api_key_name = "DEEPSEEK_API_KEY",
        endpoint = "https://api.deepseek.com",
        model = "deepseek-v4-flash",
      },
    },
    selector = {
      provider = "snacks",
      provider_opts = { },
    },
    input = {
      provider = "snacks",
      provider_opts = {
        -- title = "Avante Input",
        -- icon = " ",
      },
    },
  },
}
