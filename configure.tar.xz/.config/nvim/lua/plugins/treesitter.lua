return {
  "nvim-treesitter/nvim-treesitter",
  lazy = false,
  build = ":TSUpdate",
  config = function()
    require('nvim-treesitter').install {
      'python', 'lua', 'go', 'rust', 'javascript', 'c', 'cpp',
      'html', 'json', 'yaml', 'markdown', 'markdown_inline',
      'bash', 'dockerfile', 'vim', 'vimdoc', 'doxygen',
      'mermaid', 'make', 'xml', 'latex',
    }

    vim.api.nvim_create_autocmd('FileType', {
      pattern = {
        'python', 'lua', 'go', 'rust', 'javascript', 'c', 'cpp',
        'html', 'json', 'yaml', 'markdown', 'markdown_inline',
        'bash', 'dockerfile', 'vim', 'vimdoc', 'doxygen',
        'mermaid', 'make', 'xml', 'latex',
      },
        callback = function() 
          vim.treesitter.start()
          -- vim.bo.indentexpr = "v:lua.require'nvim-treesitter'.indentexpr()"
        end,
      })
  end,
}
