return {
  'MeanderingProgrammer/render-markdown.nvim',
  dependencies = {
    'nvim-treesitter/nvim-treesitter',
    'nvim-tree/nvim-web-devicons' 
  },
  opts = {
    file_types = { "markdown", "Avante" },
    completions = {
      lsp = {
        enabled = true,
      }
    }
  },
  ft = { "markdown", "Avante" },
}
