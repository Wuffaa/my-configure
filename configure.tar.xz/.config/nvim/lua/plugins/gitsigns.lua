return {
	"lewis6991/gitsigns.nvim",
  opts = {
    current_line_blame = true,
    word_diff = true,
    numhl = true,
  },
  config = function(_, opts)
    require("gitsigns").setup(opts)

    local gitsigns = require("gitsigns")

    local function map(mode, l, r, opts)
      opts = opts or {}
      opts.buffer = bufnr
      vim.keymap.set(mode, l, r, opts)
    end

    -- Navigation
    map('n', ']c', 
    function()
      if vim.wo.diff then
        vim.cmd.normal({']c', bang = true})
      else
        gitsigns.nav_hunk('next')
      end
    end,
    { desc = "Jump to the next hunk" })

    map('n', '[c',
    function()
      if vim.wo.diff then
        vim.cmd.normal({'[c', bang = true})
      else
        gitsigns.nav_hunk('prev')
      end
    end,
    { desc = "Jump to the prev hunk" })

    -- Actions
    map('n', '<leader>js', gitsigns.stage_hunk, { desc = "Stage hunk" })
    map('n', '<leader>jr', gitsigns.reset_hunk, { desc = "Reset hunk" })
    map('v', '<leader>js', function() gitsigns.stage_hunk {vim.fn.line('.'), vim.fn.line('v')} end, { desc = "Stage hunk" })
    map('v', '<leader>jr', function() gitsigns.reset_hunk {vim.fn.line('.'), vim.fn.line('v')} end, { desc = "Reset hunk" })
    map('n', '<leader>jS', gitsigns.stage_buffer, { desc = "Stage buffer(all hunk)" })
    map('n', '<leader>jR', gitsigns.reset_buffer, { desc = "Reset buffer(all hunk)" })
    map('n', '<leader>ju', gitsigns.undo_stage_hunk, { desc = "Undo stage hunk" })
    map('n', '<leader>jp', gitsigns.preview_hunk, { desc = "Preview hunk" })
    map('n', '<leader>jb', function() gitsigns.blame_line{full=true} end, { desc = "Blame" })
    map('n', '<leader>jd', gitsigns.diffthis, { desc = "Diff view Stage" })
    map('n', '<leader>jD', function() gitsigns.diffthis('~') end, { desc = "Diff view Commit" })
  end,
}
