return {
  "rmagatti/goto-preview",
  dependencies = { "rmagatti/logger.nvim" },
  event = "BufEnter",
  config = true,
  opts = {
    width = 85,
    height = 20,
    opacity = 35,
    same_file_float_preview = false,
    references = {
      provider = "snacks",
    },
  },
  keys = {
    {
      "<leader>r",
      function() require('goto-preview').goto_preview_references() end,
      { noremap = true, desc = "Goto preview references" }
    },
    {
      "<leader>d",
      function() require('goto-preview').goto_preview_definition() end,
      { noremap=true, desc = "Goto preview definition" }
    },
    {
      "<leader>D",
      function() require('goto-preview').goto_preview_declaration() end,
      { noremap=true, desc = "Goto preview declaration" }
    },
    {
      "<leader>t",
      function() require('goto-preview').goto_preview_type_definition() end,
      { noremap=true, desc = "Goto preview type definition" }
    },
    {
      "<leader>c",
      function() require('goto-preview').close_all_win() end,
      { noremap=true, desc = "Close all window" }
    },
  },
}
