return {
	'akinsho/bufferline.nvim', 
	dependencies = 'nvim-tree/nvim-web-devicons',
  opts = {
    options = {
      mode = "tabs",
      indicator = {
        style = 'icon',
      },
      color_icons = true,
    }
  }
}
