return {
  "catppuccin/nvim",
  name = "catppuccin",
  priority = 1000,
  config = function()
    require("catppuccin").setup({
      flavour = "mocha",
      transparent_background = true,
      float = {
        transparent = true, -- enable transparent floating windows
        solid = false, -- use solid styling for floating windows, see |winborder|
      },
      term_colors = true,
      integrations = {
        notify = true,
        noice = true,
      },
    })
    vim.cmd.colorscheme "catppuccin-nvim"
  end,
}
