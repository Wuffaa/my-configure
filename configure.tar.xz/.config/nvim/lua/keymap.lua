vim.keymap.set('n', '<leader>n', '<C-w>T', { desc = "Window to TabPage" })
vim.keymap.set('n', '<leader>h', '<cmd>tabprevious<Cr>', { desc = "Prev TabPage" })
vim.keymap.set('n', '<leader>l', '<cmd>tabnext<Cr>', { desc = "Next TabPage" })
vim.keymap.set('n', '<leader>k', '<cmd>tabclose<Cr>', { desc = "Close TabPage" })

-- neovide
local change_scale_factor = function(delta)
  vim.g.neovide_scale_factor = vim.g.neovide_scale_factor * delta
end
vim.keymap.set("n", "<C-=>", function()
  change_scale_factor(1.125)
end)
vim.keymap.set("n", "<C-->", function()
  change_scale_factor(1/1.125)
end)

local change_mac_full_screen = function()
	if vim.g.neovide_macos_simple_fullscreen == true then
		vim.g.neovide_macos_simple_fullscreen = false
	else
		vim.g.neovide_macos_simple_fullscreen = true
	end
end

vim.keymap.set("n", "<D-CR>", function()
	change_mac_full_screen()
end)

local change_full_screen = function()
	if vim.g.neovide_fullscreen == true then
		vim.g.neovide_fullscreen = false
	else
		vim.g.neovide_fullscreen = true
	end
end

vim.keymap.set("n", "<F11>", function()
	change_full_screen()
end)
