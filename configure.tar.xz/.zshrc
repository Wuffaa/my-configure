# Lines configured by zsh-newuser-install
HISTFILE=~/.histfile
HISTSIZE=1000
SAVEHIST=1000
bindkey -e
# End of lines configured by zsh-newuser-install
# The following lines were added by compinstall
zstyle :compinstall filename "$HOME/.zshrc"

autoload -Uz compinit
compinit
# End of lines added by compinstall

setopt no_nomatch

autoload -U colors && colors
PS1="%{$fg[cyan]%}╭─%B%{$fg[cyan]%}[%{$fg[yellow]%}%n%{$fg[green]%}@%{$fg[blue]%}%M %{$fg[magenta]%}%~%{$fg[cyan]%}]
%{$fg[cyan]%}╰─%{$reset_color%}$%b "

# Basic auto/tab complete
autoload -U compinit
zstyle ':completion:*' menu select
zmodload zsh/complist
setopt extendedglob
_comp_options+=(globdots)

# Alias
alias grep='grep --color=auto'
alias fgrep='fgrep --color=auto'
alias egrep='egrep --color=auto'
alias ls='ls --color=auto'
alias ll='ls -alhF'
alias la='ls -A'
alias l='ls -CF'
alias mv='mv -i'
alias vi='nvim'
alias vim='nvim'

# Env
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
export DEEPSEEK_API_KEY=$(pass api/deepseek)
export CLASHCTL_HOME="$HOME/clashctl"
if [ -f "$CLASHCTL_HOME/scripts/cmd/clashctl.sh" ]; then
    . "$CLASHCTL_HOME/scripts/cmd/clashctl.sh"
fi

# Plugin
source ~/.config/zsh/fast-syntax-highlighting/fast-syntax-highlighting.plugin.zsh
source ~/.config/zsh/zsh-autosuggestions/zsh-autosuggestions.plugin.zsh
source <(fzf --zsh)
